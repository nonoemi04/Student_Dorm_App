﻿namespace StudentDormApp
{
    partial class AnnComStudent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.AnnComPage_SA_lb = new System.Windows.Forms.ListBox();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.AnnComPage_CCC_tb = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.AnnComPage_CCT_tb = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.AnnComPage_CCD_dp = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.AnnComPage_CC_btn = new System.Windows.Forms.Button();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.AnnComPage_SA_lb);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Location = new System.Drawing.Point(16, 15);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(372, 383);
            this.panel2.TabIndex = 5;
            // 
            // AnnComPage_SA_lb
            // 
            this.AnnComPage_SA_lb.FormattingEnabled = true;
            this.AnnComPage_SA_lb.ItemHeight = 16;
            this.AnnComPage_SA_lb.Location = new System.Drawing.Point(4, 20);
            this.AnnComPage_SA_lb.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.AnnComPage_SA_lb.Name = "AnnComPage_SA_lb";
            this.AnnComPage_SA_lb.Size = new System.Drawing.Size(363, 356);
            this.AnnComPage_SA_lb.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(4, 0);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(148, 16);
            this.label3.TabIndex = 3;
            this.label3.Text = "Current Announcements";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.AnnComPage_CCC_tb);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.AnnComPage_CCT_tb);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.AnnComPage_CCD_dp);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.AnnComPage_CC_btn);
            this.panel1.Location = new System.Drawing.Point(396, 15);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(348, 384);
            this.panel1.TabIndex = 6;
            // 
            // AnnComPage_CCC_tb
            // 
            this.AnnComPage_CCC_tb.Location = new System.Drawing.Point(71, 65);
            this.AnnComPage_CCC_tb.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.AnnComPage_CCC_tb.Multiline = true;
            this.AnnComPage_CCC_tb.Name = "AnnComPage_CCC_tb";
            this.AnnComPage_CCC_tb.Size = new System.Drawing.Size(265, 207);
            this.AnnComPage_CCC_tb.TabIndex = 0;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(4, 74);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 16);
            this.label5.TabIndex = 3;
            this.label5.Text = "Content";
            // 
            // AnnComPage_CCT_tb
            // 
            this.AnnComPage_CCT_tb.Location = new System.Drawing.Point(71, 33);
            this.AnnComPage_CCT_tb.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.AnnComPage_CCT_tb.Name = "AnnComPage_CCT_tb";
            this.AnnComPage_CCT_tb.Size = new System.Drawing.Size(265, 22);
            this.AnnComPage_CCT_tb.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(4, 42);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(33, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "Title";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(4, 0);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(110, 16);
            this.label2.TabIndex = 3;
            this.label2.Text = "Create Complaint";
            // 
            // AnnComPage_CCD_dp
            // 
            this.AnnComPage_CCD_dp.Location = new System.Drawing.Point(71, 281);
            this.AnnComPage_CCD_dp.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.AnnComPage_CCD_dp.Name = "AnnComPage_CCD_dp";
            this.AnnComPage_CCD_dp.Size = new System.Drawing.Size(265, 22);
            this.AnnComPage_CCD_dp.TabIndex = 1;
            this.AnnComPage_CCD_dp.Value = new System.DateTime(2023, 4, 21, 12, 28, 50, 0);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(4, 0);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 16);
            this.label1.TabIndex = 3;
            // 
            // AnnComPage_CC_btn
            // 
            this.AnnComPage_CC_btn.Location = new System.Drawing.Point(127, 324);
            this.AnnComPage_CC_btn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.AnnComPage_CC_btn.Name = "AnnComPage_CC_btn";
            this.AnnComPage_CC_btn.Size = new System.Drawing.Size(168, 28);
            this.AnnComPage_CC_btn.TabIndex = 2;
            this.AnnComPage_CC_btn.Text = "Create Complaint";
            this.AnnComPage_CC_btn.UseVisualStyleBackColor = true;
            this.AnnComPage_CC_btn.Click += new System.EventHandler(this.AnnComPage_CC_btn_Click);
            // 
            // AnnComStudent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(760, 409);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "AnnComStudent";
            this.Text = "AnnComStudent";
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ListBox AnnComPage_SA_lb;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox AnnComPage_CCC_tb;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox AnnComPage_CCT_tb;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker AnnComPage_CCD_dp;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button AnnComPage_CC_btn;
    }
}