﻿namespace WindowsFormsApp1
{
    partial class RoomManagementPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel6 = new System.Windows.Forms.Panel();
            this.RoomNo_lbl = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.label45 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label50 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.label47 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.Facultate3 = new System.Windows.Forms.Label();
            this.Prenume3 = new System.Windows.Forms.Label();
            this.An3 = new System.Windows.Forms.Label();
            this.Nume3 = new System.Windows.Forms.Label();
            this.Contact3 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label23 = new System.Windows.Forms.Label();
            this.PCD3 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.RoomManagementPage_S3RS_btn = new System.Windows.Forms.Button();
            this.RoomManagementPage_S3CS_btn = new System.Windows.Forms.Button();
            this.RoomManagement_S3ID_tb = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.An4 = new System.Windows.Forms.Label();
            this.Prenume4 = new System.Windows.Forms.Label();
            this.Facultate4 = new System.Windows.Forms.Label();
            this.Nume4 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.Contact4 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.PCD4 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.RoomManagementPage_S4RS_btn = new System.Windows.Forms.Button();
            this.RoomManagementPage_S4CS_btn = new System.Windows.Forms.Button();
            this.RoomManagement_S4ID_tb = new System.Windows.Forms.TextBox();
            this.panel6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.RoomNo_lbl);
            this.panel6.Location = new System.Drawing.Point(14, 13);
            this.panel6.Margin = new System.Windows.Forms.Padding(4);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(1059, 52);
            this.panel6.TabIndex = 0;
            // 
            // RoomNo_lbl
            // 
            this.RoomNo_lbl.AutoSize = true;
            this.RoomNo_lbl.Location = new System.Drawing.Point(-4, 0);
            this.RoomNo_lbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.RoomNo_lbl.Name = "RoomNo_lbl";
            this.RoomNo_lbl.Size = new System.Drawing.Size(79, 16);
            this.RoomNo_lbl.TabIndex = 1;
            this.RoomNo_lbl.Text = "Camera ###";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.panel6);
            this.groupBox5.Controls.Add(this.groupBox4);
            this.groupBox5.Controls.Add(this.groupBox3);
            this.groupBox5.Controls.Add(this.groupBox2);
            this.groupBox5.Controls.Add(this.groupBox1);
            this.groupBox5.Location = new System.Drawing.Point(12, 1);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(1094, 580);
            this.groupBox5.TabIndex = 2;
            this.groupBox5.TabStop = false;
            this.groupBox5.Enter += new System.EventHandler(this.groupBox5_Enter);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label34);
            this.groupBox1.Controls.Add(this.label35);
            this.groupBox1.Controls.Add(this.label36);
            this.groupBox1.Controls.Add(this.label37);
            this.groupBox1.Controls.Add(this.label38);
            this.groupBox1.Controls.Add(this.label39);
            this.groupBox1.Controls.Add(this.label40);
            this.groupBox1.Controls.Add(this.label41);
            this.groupBox1.Controls.Add(this.label42);
            this.groupBox1.Controls.Add(this.label43);
            this.groupBox1.Controls.Add(this.label44);
            this.groupBox1.Controls.Add(this.label45);
            this.groupBox1.Controls.Add(this.pictureBox4);
            this.groupBox1.Location = new System.Drawing.Point(12, 72);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(527, 246);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Student 1";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Location = new System.Drawing.Point(26, 33);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(111, 130);
            this.pictureBox4.TabIndex = 4;
            this.pictureBox4.TabStop = false;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(145, 33);
            this.label45.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(43, 16);
            this.label45.TabIndex = 5;
            this.label45.Text = "Nume";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(219, 33);
            this.label44.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(43, 16);
            this.label44.TabIndex = 6;
            this.label44.Text = "Nume";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(219, 49);
            this.label43.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(61, 16);
            this.label43.TabIndex = 7;
            this.label43.Text = "Prenume";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(219, 65);
            this.label42.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(23, 16);
            this.label42.TabIndex = 8;
            this.label42.Text = "An";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(219, 81);
            this.label41.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(62, 16);
            this.label41.TabIndex = 9;
            this.label41.Text = "Facultate";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(219, 97);
            this.label40.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(45, 16);
            this.label40.TabIndex = 10;
            this.label40.Text = "Sectia";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(219, 113);
            this.label39.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(46, 16);
            this.label39.TabIndex = 11;
            this.label39.Text = "Da/Nu";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(145, 49);
            this.label38.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(61, 16);
            this.label38.TabIndex = 12;
            this.label38.Text = "Prenume";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(145, 65);
            this.label37.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(62, 16);
            this.label37.TabIndex = 13;
            this.label37.Text = "An curent";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(145, 81);
            this.label36.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(62, 16);
            this.label36.TabIndex = 14;
            this.label36.Text = "Facultate";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(145, 97);
            this.label35.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(52, 16);
            this.label35.TabIndex = 15;
            this.label35.Text = "Contact";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(145, 113);
            this.label34.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(35, 16);
            this.label34.TabIndex = 16;
            this.label34.Text = "PCD";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(170, 174);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(18, 16);
            this.label8.TabIndex = 17;
            this.label8.Text = "Id";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(206, 205);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(152, 28);
            this.button2.TabIndex = 19;
            this.button2.Text = "Remove Student";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(354, 166);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(147, 28);
            this.button1.TabIndex = 20;
            this.button1.Text = "Change Student";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(213, 169);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(132, 22);
            this.textBox1.TabIndex = 21;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.textBox2);
            this.groupBox2.Controls.Add(this.button3);
            this.groupBox2.Controls.Add(this.button4);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label29);
            this.groupBox2.Controls.Add(this.label46);
            this.groupBox2.Controls.Add(this.label47);
            this.groupBox2.Controls.Add(this.pictureBox5);
            this.groupBox2.Controls.Add(this.label48);
            this.groupBox2.Controls.Add(this.label49);
            this.groupBox2.Controls.Add(this.label50);
            this.groupBox2.Location = new System.Drawing.Point(546, 72);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(527, 246);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Student 2";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(233, 39);
            this.label50.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(61, 16);
            this.label50.TabIndex = 12;
            this.label50.Text = "Prenume";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(233, 23);
            this.label49.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(43, 16);
            this.label49.TabIndex = 11;
            this.label49.Text = "Nume";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(233, 55);
            this.label48.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(23, 16);
            this.label48.TabIndex = 6;
            this.label48.Text = "An";
            // 
            // pictureBox5
            // 
            this.pictureBox5.Location = new System.Drawing.Point(26, 23);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(111, 130);
            this.pictureBox5.TabIndex = 4;
            this.pictureBox5.TabStop = false;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(233, 71);
            this.label47.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(62, 16);
            this.label47.TabIndex = 7;
            this.label47.Text = "Facultate";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(233, 87);
            this.label46.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(45, 16);
            this.label46.TabIndex = 8;
            this.label46.Text = "Sectia";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(145, 23);
            this.label29.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(43, 16);
            this.label29.TabIndex = 9;
            this.label29.Text = "Nume";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(233, 103);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(46, 16);
            this.label7.TabIndex = 10;
            this.label7.Text = "Da/Nu";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(145, 39);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 16);
            this.label6.TabIndex = 5;
            this.label6.Text = "Prenume";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(145, 55);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(62, 16);
            this.label5.TabIndex = 17;
            this.label5.Text = "An curent";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(145, 71);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 16);
            this.label4.TabIndex = 13;
            this.label4.Text = "Facultate";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(145, 87);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 16);
            this.label3.TabIndex = 14;
            this.label3.Text = "Contact";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(145, 103);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 16);
            this.label2.TabIndex = 15;
            this.label2.Text = "PCD";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(170, 164);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(18, 16);
            this.label1.TabIndex = 16;
            this.label1.Text = "Id";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(206, 195);
            this.button4.Margin = new System.Windows.Forms.Padding(4);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(152, 28);
            this.button4.TabIndex = 18;
            this.button4.Text = "Remove Student";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(354, 156);
            this.button3.Margin = new System.Windows.Forms.Padding(4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(147, 28);
            this.button3.TabIndex = 19;
            this.button3.Text = "Change Student";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(213, 159);
            this.textBox2.Margin = new System.Windows.Forms.Padding(4);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(132, 22);
            this.textBox2.TabIndex = 20;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.RoomManagement_S3ID_tb);
            this.groupBox3.Controls.Add(this.RoomManagementPage_S3CS_btn);
            this.groupBox3.Controls.Add(this.RoomManagementPage_S3RS_btn);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Controls.Add(this.label18);
            this.groupBox3.Controls.Add(this.label19);
            this.groupBox3.Controls.Add(this.label20);
            this.groupBox3.Controls.Add(this.label21);
            this.groupBox3.Controls.Add(this.label22);
            this.groupBox3.Controls.Add(this.PCD3);
            this.groupBox3.Controls.Add(this.label23);
            this.groupBox3.Controls.Add(this.pictureBox2);
            this.groupBox3.Controls.Add(this.Contact3);
            this.groupBox3.Controls.Add(this.Nume3);
            this.groupBox3.Controls.Add(this.An3);
            this.groupBox3.Controls.Add(this.Prenume3);
            this.groupBox3.Controls.Add(this.Facultate3);
            this.groupBox3.Location = new System.Drawing.Point(13, 324);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(527, 246);
            this.groupBox3.TabIndex = 4;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Student 3";
            // 
            // Facultate3
            // 
            this.Facultate3.AutoSize = true;
            this.Facultate3.Location = new System.Drawing.Point(219, 71);
            this.Facultate3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Facultate3.Name = "Facultate3";
            this.Facultate3.Size = new System.Drawing.Size(62, 16);
            this.Facultate3.TabIndex = 12;
            this.Facultate3.Text = "Facultate";
            // 
            // Prenume3
            // 
            this.Prenume3.AutoSize = true;
            this.Prenume3.Location = new System.Drawing.Point(219, 39);
            this.Prenume3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Prenume3.Name = "Prenume3";
            this.Prenume3.Size = new System.Drawing.Size(61, 16);
            this.Prenume3.TabIndex = 11;
            this.Prenume3.Text = "Prenume";
            // 
            // An3
            // 
            this.An3.AutoSize = true;
            this.An3.Location = new System.Drawing.Point(219, 55);
            this.An3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.An3.Name = "An3";
            this.An3.Size = new System.Drawing.Size(23, 16);
            this.An3.TabIndex = 6;
            this.An3.Text = "An";
            // 
            // Nume3
            // 
            this.Nume3.AutoSize = true;
            this.Nume3.Location = new System.Drawing.Point(219, 23);
            this.Nume3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Nume3.Name = "Nume3";
            this.Nume3.Size = new System.Drawing.Size(43, 16);
            this.Nume3.TabIndex = 7;
            this.Nume3.Text = "Nume";
            // 
            // Contact3
            // 
            this.Contact3.AutoSize = true;
            this.Contact3.Location = new System.Drawing.Point(219, 87);
            this.Contact3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Contact3.Name = "Contact3";
            this.Contact3.Size = new System.Drawing.Size(45, 16);
            this.Contact3.TabIndex = 8;
            this.Contact3.Text = "Sectia";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(26, 23);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(111, 130);
            this.pictureBox2.TabIndex = 4;
            this.pictureBox2.TabStop = false;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(145, 23);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(43, 16);
            this.label23.TabIndex = 9;
            this.label23.Text = "Nume";
            // 
            // PCD3
            // 
            this.PCD3.AutoSize = true;
            this.PCD3.Location = new System.Drawing.Point(219, 103);
            this.PCD3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.PCD3.Name = "PCD3";
            this.PCD3.Size = new System.Drawing.Size(46, 16);
            this.PCD3.TabIndex = 10;
            this.PCD3.Text = "Da/Nu";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(145, 39);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(61, 16);
            this.label22.TabIndex = 5;
            this.label22.Text = "Prenume";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(145, 55);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(62, 16);
            this.label21.TabIndex = 17;
            this.label21.Text = "An curent";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(145, 71);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(62, 16);
            this.label20.TabIndex = 13;
            this.label20.Text = "Facultate";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(145, 87);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(52, 16);
            this.label19.TabIndex = 14;
            this.label19.Text = "Contact";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(145, 103);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(35, 16);
            this.label18.TabIndex = 15;
            this.label18.Text = "PCD";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(170, 164);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(18, 16);
            this.label17.TabIndex = 16;
            this.label17.Text = "Id";
            // 
            // RoomManagementPage_S3RS_btn
            // 
            this.RoomManagementPage_S3RS_btn.Location = new System.Drawing.Point(206, 195);
            this.RoomManagementPage_S3RS_btn.Margin = new System.Windows.Forms.Padding(4);
            this.RoomManagementPage_S3RS_btn.Name = "RoomManagementPage_S3RS_btn";
            this.RoomManagementPage_S3RS_btn.Size = new System.Drawing.Size(152, 28);
            this.RoomManagementPage_S3RS_btn.TabIndex = 18;
            this.RoomManagementPage_S3RS_btn.Text = "Remove Student";
            this.RoomManagementPage_S3RS_btn.UseVisualStyleBackColor = true;
            // 
            // RoomManagementPage_S3CS_btn
            // 
            this.RoomManagementPage_S3CS_btn.Location = new System.Drawing.Point(354, 156);
            this.RoomManagementPage_S3CS_btn.Margin = new System.Windows.Forms.Padding(4);
            this.RoomManagementPage_S3CS_btn.Name = "RoomManagementPage_S3CS_btn";
            this.RoomManagementPage_S3CS_btn.Size = new System.Drawing.Size(147, 28);
            this.RoomManagementPage_S3CS_btn.TabIndex = 19;
            this.RoomManagementPage_S3CS_btn.Text = "Change Student";
            this.RoomManagementPage_S3CS_btn.UseVisualStyleBackColor = true;
            // 
            // RoomManagement_S3ID_tb
            // 
            this.RoomManagement_S3ID_tb.Location = new System.Drawing.Point(213, 159);
            this.RoomManagement_S3ID_tb.Margin = new System.Windows.Forms.Padding(4);
            this.RoomManagement_S3ID_tb.Name = "RoomManagement_S3ID_tb";
            this.RoomManagement_S3ID_tb.Size = new System.Drawing.Size(132, 22);
            this.RoomManagement_S3ID_tb.TabIndex = 20;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.RoomManagement_S4ID_tb);
            this.groupBox4.Controls.Add(this.RoomManagementPage_S4CS_btn);
            this.groupBox4.Controls.Add(this.RoomManagementPage_S4RS_btn);
            this.groupBox4.Controls.Add(this.label25);
            this.groupBox4.Controls.Add(this.label26);
            this.groupBox4.Controls.Add(this.label27);
            this.groupBox4.Controls.Add(this.label28);
            this.groupBox4.Controls.Add(this.label30);
            this.groupBox4.Controls.Add(this.label31);
            this.groupBox4.Controls.Add(this.PCD4);
            this.groupBox4.Controls.Add(this.label32);
            this.groupBox4.Controls.Add(this.Contact4);
            this.groupBox4.Controls.Add(this.pictureBox3);
            this.groupBox4.Controls.Add(this.Nume4);
            this.groupBox4.Controls.Add(this.Facultate4);
            this.groupBox4.Controls.Add(this.Prenume4);
            this.groupBox4.Controls.Add(this.An4);
            this.groupBox4.Location = new System.Drawing.Point(546, 324);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(527, 246);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Student 4";
            // 
            // An4
            // 
            this.An4.AutoSize = true;
            this.An4.Location = new System.Drawing.Point(233, 55);
            this.An4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.An4.Name = "An4";
            this.An4.Size = new System.Drawing.Size(23, 16);
            this.An4.TabIndex = 12;
            this.An4.Text = "An";
            // 
            // Prenume4
            // 
            this.Prenume4.AutoSize = true;
            this.Prenume4.Location = new System.Drawing.Point(233, 39);
            this.Prenume4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Prenume4.Name = "Prenume4";
            this.Prenume4.Size = new System.Drawing.Size(61, 16);
            this.Prenume4.TabIndex = 11;
            this.Prenume4.Text = "Prenume";
            // 
            // Facultate4
            // 
            this.Facultate4.AutoSize = true;
            this.Facultate4.Location = new System.Drawing.Point(233, 71);
            this.Facultate4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Facultate4.Name = "Facultate4";
            this.Facultate4.Size = new System.Drawing.Size(62, 16);
            this.Facultate4.TabIndex = 6;
            this.Facultate4.Text = "Facultate";
            // 
            // Nume4
            // 
            this.Nume4.AutoSize = true;
            this.Nume4.Location = new System.Drawing.Point(233, 23);
            this.Nume4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Nume4.Name = "Nume4";
            this.Nume4.Size = new System.Drawing.Size(43, 16);
            this.Nume4.TabIndex = 7;
            this.Nume4.Text = "Nume";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Location = new System.Drawing.Point(26, 23);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(111, 130);
            this.pictureBox3.TabIndex = 4;
            this.pictureBox3.TabStop = false;
            // 
            // Contact4
            // 
            this.Contact4.AutoSize = true;
            this.Contact4.Location = new System.Drawing.Point(233, 87);
            this.Contact4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Contact4.Name = "Contact4";
            this.Contact4.Size = new System.Drawing.Size(45, 16);
            this.Contact4.TabIndex = 8;
            this.Contact4.Text = "Sectia";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(145, 23);
            this.label32.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(43, 16);
            this.label32.TabIndex = 9;
            this.label32.Text = "Nume";
            // 
            // PCD4
            // 
            this.PCD4.AutoSize = true;
            this.PCD4.Location = new System.Drawing.Point(233, 103);
            this.PCD4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.PCD4.Name = "PCD4";
            this.PCD4.Size = new System.Drawing.Size(46, 16);
            this.PCD4.TabIndex = 10;
            this.PCD4.Text = "Da/Nu";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(145, 39);
            this.label31.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(61, 16);
            this.label31.TabIndex = 5;
            this.label31.Text = "Prenume";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(145, 55);
            this.label30.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(62, 16);
            this.label30.TabIndex = 17;
            this.label30.Text = "An curent";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(145, 71);
            this.label28.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(62, 16);
            this.label28.TabIndex = 13;
            this.label28.Text = "Facultate";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(145, 87);
            this.label27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(52, 16);
            this.label27.TabIndex = 14;
            this.label27.Text = "Contact";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(145, 103);
            this.label26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(35, 16);
            this.label26.TabIndex = 15;
            this.label26.Text = "PCD";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(170, 164);
            this.label25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(18, 16);
            this.label25.TabIndex = 16;
            this.label25.Text = "Id";
            // 
            // RoomManagementPage_S4RS_btn
            // 
            this.RoomManagementPage_S4RS_btn.Location = new System.Drawing.Point(206, 195);
            this.RoomManagementPage_S4RS_btn.Margin = new System.Windows.Forms.Padding(4);
            this.RoomManagementPage_S4RS_btn.Name = "RoomManagementPage_S4RS_btn";
            this.RoomManagementPage_S4RS_btn.Size = new System.Drawing.Size(152, 28);
            this.RoomManagementPage_S4RS_btn.TabIndex = 18;
            this.RoomManagementPage_S4RS_btn.Text = "Remove Student";
            this.RoomManagementPage_S4RS_btn.UseVisualStyleBackColor = true;
            // 
            // RoomManagementPage_S4CS_btn
            // 
            this.RoomManagementPage_S4CS_btn.Location = new System.Drawing.Point(354, 156);
            this.RoomManagementPage_S4CS_btn.Margin = new System.Windows.Forms.Padding(4);
            this.RoomManagementPage_S4CS_btn.Name = "RoomManagementPage_S4CS_btn";
            this.RoomManagementPage_S4CS_btn.Size = new System.Drawing.Size(147, 28);
            this.RoomManagementPage_S4CS_btn.TabIndex = 19;
            this.RoomManagementPage_S4CS_btn.Text = "Change Student";
            this.RoomManagementPage_S4CS_btn.UseVisualStyleBackColor = true;
            // 
            // RoomManagement_S4ID_tb
            // 
            this.RoomManagement_S4ID_tb.Location = new System.Drawing.Point(213, 159);
            this.RoomManagement_S4ID_tb.Margin = new System.Windows.Forms.Padding(4);
            this.RoomManagement_S4ID_tb.Name = "RoomManagement_S4ID_tb";
            this.RoomManagement_S4ID_tb.Size = new System.Drawing.Size(132, 22);
            this.RoomManagement_S4ID_tb.TabIndex = 20;
            // 
            // RoomManagementPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1118, 593);
            this.Controls.Add(this.groupBox5);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "RoomManagementPage";
            this.Text = "RoomManagementPage";
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label RoomNo_lbl;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox RoomManagement_S4ID_tb;
        private System.Windows.Forms.Button RoomManagementPage_S4CS_btn;
        private System.Windows.Forms.Button RoomManagementPage_S4RS_btn;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label PCD4;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label Contact4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label Nume4;
        private System.Windows.Forms.Label Facultate4;
        private System.Windows.Forms.Label Prenume4;
        private System.Windows.Forms.Label An4;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox RoomManagement_S3ID_tb;
        private System.Windows.Forms.Button RoomManagementPage_S3CS_btn;
        private System.Windows.Forms.Button RoomManagementPage_S3RS_btn;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label PCD3;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label Contact3;
        private System.Windows.Forms.Label Nume3;
        private System.Windows.Forms.Label An3;
        private System.Windows.Forms.Label Prenume3;
        private System.Windows.Forms.Label Facultate3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.PictureBox pictureBox4;
    }
}