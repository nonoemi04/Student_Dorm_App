﻿namespace WindowsFormsApp1
{
    partial class AdminForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.AdminPage_COP_btn = new System.Windows.Forms.Button();
            this.AdminPage_R_btn = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.AdminPage_RN_tb = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.AdminPage_MR_btn = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.AdminPage_AS_btn = new System.Windows.Forms.Button();
            this.AdminPage_SC_btn = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.AdminPage_MA_btn = new System.Windows.Forms.Button();
            this.AdminPage_SA_btn = new System.Windows.Forms.Button();
            this.AdminPage_MA_lbl = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel6);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(17, 16);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(455, 263);
            this.panel1.TabIndex = 0;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.label5);
            this.panel6.Controls.Add(this.AdminPage_COP_btn);
            this.panel6.Controls.Add(this.AdminPage_R_btn);
            this.panel6.Location = new System.Drawing.Point(231, 4);
            this.panel6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(219, 128);
            this.panel6.TabIndex = 0;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(4, 0);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(67, 16);
            this.label5.TabIndex = 0;
            this.label5.Text = "Payments";
            // 
            // AdminPage_COP_btn
            // 
            this.AdminPage_COP_btn.Location = new System.Drawing.Point(19, 67);
            this.AdminPage_COP_btn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.AdminPage_COP_btn.Name = "AdminPage_COP_btn";
            this.AdminPage_COP_btn.Size = new System.Drawing.Size(167, 28);
            this.AdminPage_COP_btn.TabIndex = 1;
            this.AdminPage_COP_btn.Text = "Check other payments";
            this.AdminPage_COP_btn.UseVisualStyleBackColor = true;
            this.AdminPage_COP_btn.Click += new System.EventHandler(this.AdminPage_COP_btn_Click);
            // 
            // AdminPage_R_btn
            // 
            this.AdminPage_R_btn.Location = new System.Drawing.Point(19, 31);
            this.AdminPage_R_btn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.AdminPage_R_btn.Name = "AdminPage_R_btn";
            this.AdminPage_R_btn.Size = new System.Drawing.Size(167, 28);
            this.AdminPage_R_btn.TabIndex = 1;
            this.AdminPage_R_btn.Text = "Rents&Penalties";
            this.AdminPage_R_btn.UseVisualStyleBackColor = true;
            this.AdminPage_R_btn.Click += new System.EventHandler(this.AdminPage_R_btn_Click);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.AdminPage_RN_tb);
            this.panel4.Controls.Add(this.label7);
            this.panel4.Controls.Add(this.label3);
            this.panel4.Controls.Add(this.AdminPage_MR_btn);
            this.panel4.Location = new System.Drawing.Point(231, 139);
            this.panel4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(219, 119);
            this.panel4.TabIndex = 0;
            // 
            // AdminPage_RN_tb
            // 
            this.AdminPage_RN_tb.Location = new System.Drawing.Point(97, 31);
            this.AdminPage_RN_tb.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.AdminPage_RN_tb.Name = "AdminPage_RN_tb";
            this.AdminPage_RN_tb.Size = new System.Drawing.Size(88, 22);
            this.AdminPage_RN_tb.TabIndex = 2;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(16, 34);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(68, 16);
            this.label7.TabIndex = 0;
            this.label7.Text = "Room No.";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(4, 0);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(126, 16);
            this.label3.TabIndex = 0;
            this.label3.Text = "Room Management";
            // 
            // AdminPage_MR_btn
            // 
            this.AdminPage_MR_btn.Location = new System.Drawing.Point(20, 63);
            this.AdminPage_MR_btn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.AdminPage_MR_btn.Name = "AdminPage_MR_btn";
            this.AdminPage_MR_btn.Size = new System.Drawing.Size(167, 28);
            this.AdminPage_MR_btn.TabIndex = 1;
            this.AdminPage_MR_btn.Text = "Manage Room";
            this.AdminPage_MR_btn.UseVisualStyleBackColor = true;
            this.AdminPage_MR_btn.Click += new System.EventHandler(this.AdminPage_MR_btn_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.AdminPage_AS_btn);
            this.panel3.Controls.Add(this.AdminPage_SC_btn);
            this.panel3.Location = new System.Drawing.Point(4, 139);
            this.panel3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(219, 119);
            this.panel3.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(4, 0);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "Complaints";
            // 
            // AdminPage_AS_btn
            // 
            this.AdminPage_AS_btn.Location = new System.Drawing.Point(20, 64);
            this.AdminPage_AS_btn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.AdminPage_AS_btn.Name = "AdminPage_AS_btn";
            this.AdminPage_AS_btn.Size = new System.Drawing.Size(167, 28);
            this.AdminPage_AS_btn.TabIndex = 1;
            this.AdminPage_AS_btn.Text = "Ask for support";
            this.AdminPage_AS_btn.UseVisualStyleBackColor = true;
            // 
            // AdminPage_SC_btn
            // 
            this.AdminPage_SC_btn.Location = new System.Drawing.Point(20, 28);
            this.AdminPage_SC_btn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.AdminPage_SC_btn.Name = "AdminPage_SC_btn";
            this.AdminPage_SC_btn.Size = new System.Drawing.Size(167, 28);
            this.AdminPage_SC_btn.TabIndex = 1;
            this.AdminPage_SC_btn.Text = "See complaints";
            this.AdminPage_SC_btn.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.AdminPage_MA_btn);
            this.panel2.Controls.Add(this.AdminPage_SA_btn);
            this.panel2.Controls.Add(this.AdminPage_MA_lbl);
            this.panel2.Location = new System.Drawing.Point(4, 4);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(219, 128);
            this.panel2.TabIndex = 0;
            // 
            // AdminPage_MA_btn
            // 
            this.AdminPage_MA_btn.Location = new System.Drawing.Point(20, 66);
            this.AdminPage_MA_btn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.AdminPage_MA_btn.Name = "AdminPage_MA_btn";
            this.AdminPage_MA_btn.Size = new System.Drawing.Size(167, 28);
            this.AdminPage_MA_btn.TabIndex = 1;
            this.AdminPage_MA_btn.Text = "Make announcement";
            this.AdminPage_MA_btn.UseVisualStyleBackColor = true;
            // 
            // AdminPage_SA_btn
            // 
            this.AdminPage_SA_btn.Location = new System.Drawing.Point(20, 31);
            this.AdminPage_SA_btn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.AdminPage_SA_btn.Name = "AdminPage_SA_btn";
            this.AdminPage_SA_btn.Size = new System.Drawing.Size(167, 28);
            this.AdminPage_SA_btn.TabIndex = 1;
            this.AdminPage_SA_btn.Text = "See announcements";
            this.AdminPage_SA_btn.UseVisualStyleBackColor = true;
            // 
            // AdminPage_MA_lbl
            // 
            this.AdminPage_MA_lbl.AutoSize = true;
            this.AdminPage_MA_lbl.Location = new System.Drawing.Point(4, 0);
            this.AdminPage_MA_lbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.AdminPage_MA_lbl.Name = "AdminPage_MA_lbl";
            this.AdminPage_MA_lbl.Size = new System.Drawing.Size(103, 16);
            this.AdminPage_MA_lbl.TabIndex = 0;
            this.AdminPage_MA_lbl.Text = "Announcements";
            // 
            // AdminForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(480, 290);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "AdminForm";
            this.Text = "AdminForm";
            this.panel1.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button AdminPage_COP_btn;
        private System.Windows.Forms.Button AdminPage_R_btn;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox AdminPage_RN_tb;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button AdminPage_MR_btn;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button AdminPage_MA_btn;
        private System.Windows.Forms.Button AdminPage_SA_btn;
        private System.Windows.Forms.Label AdminPage_MA_lbl;
        private System.Windows.Forms.Button AdminPage_AS_btn;
        private System.Windows.Forms.Button AdminPage_SC_btn;
    }
}