﻿namespace WindowsFormsApp1
{
    partial class WashingRoom
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dtpicker_DateWash = new System.Windows.Forms.DateTimePicker();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.pictureBox17 = new System.Windows.Forms.PictureBox();
            this.pictureBox18 = new System.Windows.Forms.PictureBox();
            this.pictureBox19 = new System.Windows.Forms.PictureBox();
            this.pictureBox20 = new System.Windows.Forms.PictureBox();
            this.pictureBox21 = new System.Windows.Forms.PictureBox();
            this.pictureBox22 = new System.Windows.Forms.PictureBox();
            this.pictureBox23 = new System.Windows.Forms.PictureBox();
            this.pictureBox24 = new System.Windows.Forms.PictureBox();
            this.pictureBox25 = new System.Windows.Forms.PictureBox();
            this.pictureBox26 = new System.Windows.Forms.PictureBox();
            this.pictureBox27 = new System.Windows.Forms.PictureBox();
            this.pictureBox28 = new System.Windows.Forms.PictureBox();
            this.pictureBox29 = new System.Windows.Forms.PictureBox();
            this.pictureBox30 = new System.Windows.Forms.PictureBox();
            this.pictureBox31 = new System.Windows.Forms.PictureBox();
            this.pictureBox32 = new System.Windows.Forms.PictureBox();
            this.pictureBox33 = new System.Windows.Forms.PictureBox();
            this.pictureBox34 = new System.Windows.Forms.PictureBox();
            this.pictureBox35 = new System.Windows.Forms.PictureBox();
            this.pictureBox36 = new System.Windows.Forms.PictureBox();
            this.pictureBox37 = new System.Windows.Forms.PictureBox();
            this.pictureBox38 = new System.Windows.Forms.PictureBox();
            this.pictureBox39 = new System.Windows.Forms.PictureBox();
            this.pictureBox40 = new System.Windows.Forms.PictureBox();
            this.pictureBox41 = new System.Windows.Forms.PictureBox();
            this.pictureBox42 = new System.Windows.Forms.PictureBox();
            this.pictureBox43 = new System.Windows.Forms.PictureBox();
            this.pictureBox44 = new System.Windows.Forms.PictureBox();
            this.pictureBox45 = new System.Windows.Forms.PictureBox();
            this.pictureBox46 = new System.Windows.Forms.PictureBox();
            this.pictureBox47 = new System.Windows.Forms.PictureBox();
            this.pictureBox48 = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.pictureBox49 = new System.Windows.Forms.PictureBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.pictureBox50 = new System.Windows.Forms.PictureBox();
            this.pictureBox51 = new System.Windows.Forms.PictureBox();
            this.pictureBox52 = new System.Windows.Forms.PictureBox();
            this.pictureBox53 = new System.Windows.Forms.PictureBox();
            this.pictureBox54 = new System.Windows.Forms.PictureBox();
            this.pictureBox55 = new System.Windows.Forms.PictureBox();
            this.pictureBox56 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox57 = new System.Windows.Forms.PictureBox();
            this.pictureBox58 = new System.Windows.Forms.PictureBox();
            this.pictureBox59 = new System.Windows.Forms.PictureBox();
            this.pictureBox60 = new System.Windows.Forms.PictureBox();
            this.pictureBox61 = new System.Windows.Forms.PictureBox();
            this.pictureBox62 = new System.Windows.Forms.PictureBox();
            this.pictureBox63 = new System.Windows.Forms.PictureBox();
            this.pictureBox64 = new System.Windows.Forms.PictureBox();
            this.pictureBox65 = new System.Windows.Forms.PictureBox();
            this.pictureBox66 = new System.Windows.Forms.PictureBox();
            this.pictureBox67 = new System.Windows.Forms.PictureBox();
            this.pictureBox68 = new System.Windows.Forms.PictureBox();
            this.pictureBox69 = new System.Windows.Forms.PictureBox();
            this.pictureBox70 = new System.Windows.Forms.PictureBox();
            this.pictureBox71 = new System.Windows.Forms.PictureBox();
            this.pictureBox72 = new System.Windows.Forms.PictureBox();
            this.pictureBox73 = new System.Windows.Forms.PictureBox();
            this.pictureBox74 = new System.Windows.Forms.PictureBox();
            this.pictureBox75 = new System.Windows.Forms.PictureBox();
            this.pictureBox76 = new System.Windows.Forms.PictureBox();
            this.pictureBox77 = new System.Windows.Forms.PictureBox();
            this.pictureBox78 = new System.Windows.Forms.PictureBox();
            this.pictureBox79 = new System.Windows.Forms.PictureBox();
            this.pictureBox80 = new System.Windows.Forms.PictureBox();
            this.pictureBox81 = new System.Windows.Forms.PictureBox();
            this.pictureBox82 = new System.Windows.Forms.PictureBox();
            this.pictureBox83 = new System.Windows.Forms.PictureBox();
            this.pictureBox84 = new System.Windows.Forms.PictureBox();
            this.pictureBox85 = new System.Windows.Forms.PictureBox();
            this.pictureBox86 = new System.Windows.Forms.PictureBox();
            this.pictureBox87 = new System.Windows.Forms.PictureBox();
            this.pictureBox88 = new System.Windows.Forms.PictureBox();
            this.pictureBox89 = new System.Windows.Forms.PictureBox();
            this.pictureBox90 = new System.Windows.Forms.PictureBox();
            this.pictureBox91 = new System.Windows.Forms.PictureBox();
            this.pictureBox92 = new System.Windows.Forms.PictureBox();
            this.pictureBox93 = new System.Windows.Forms.PictureBox();
            this.pictureBox94 = new System.Windows.Forms.PictureBox();
            this.pictureBox95 = new System.Windows.Forms.PictureBox();
            this.pictureBox96 = new System.Windows.Forms.PictureBox();
            this.pictureBox97 = new System.Windows.Forms.PictureBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.pictureBox98 = new System.Windows.Forms.PictureBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.pictureBox99 = new System.Windows.Forms.PictureBox();
            this.pictureBox100 = new System.Windows.Forms.PictureBox();
            this.pictureBox101 = new System.Windows.Forms.PictureBox();
            this.pictureBox102 = new System.Windows.Forms.PictureBox();
            this.pictureBox103 = new System.Windows.Forms.PictureBox();
            this.pictureBox104 = new System.Windows.Forms.PictureBox();
            this.pictureBox105 = new System.Windows.Forms.PictureBox();
            this.label33 = new System.Windows.Forms.Label();
            this.pictureBox106 = new System.Windows.Forms.PictureBox();
            this.pictureBox107 = new System.Windows.Forms.PictureBox();
            this.pictureBox108 = new System.Windows.Forms.PictureBox();
            this.pictureBox109 = new System.Windows.Forms.PictureBox();
            this.pictureBox110 = new System.Windows.Forms.PictureBox();
            this.pictureBox111 = new System.Windows.Forms.PictureBox();
            this.pictureBox112 = new System.Windows.Forms.PictureBox();
            this.pictureBox113 = new System.Windows.Forms.PictureBox();
            this.pictureBox114 = new System.Windows.Forms.PictureBox();
            this.pictureBox115 = new System.Windows.Forms.PictureBox();
            this.pictureBox116 = new System.Windows.Forms.PictureBox();
            this.pictureBox117 = new System.Windows.Forms.PictureBox();
            this.pictureBox118 = new System.Windows.Forms.PictureBox();
            this.pictureBox119 = new System.Windows.Forms.PictureBox();
            this.pictureBox120 = new System.Windows.Forms.PictureBox();
            this.pictureBox121 = new System.Windows.Forms.PictureBox();
            this.pictureBox122 = new System.Windows.Forms.PictureBox();
            this.pictureBox123 = new System.Windows.Forms.PictureBox();
            this.pictureBox124 = new System.Windows.Forms.PictureBox();
            this.pictureBox125 = new System.Windows.Forms.PictureBox();
            this.pictureBox126 = new System.Windows.Forms.PictureBox();
            this.pictureBox127 = new System.Windows.Forms.PictureBox();
            this.pictureBox128 = new System.Windows.Forms.PictureBox();
            this.pictureBox129 = new System.Windows.Forms.PictureBox();
            this.pictureBox130 = new System.Windows.Forms.PictureBox();
            this.pictureBox131 = new System.Windows.Forms.PictureBox();
            this.pictureBox132 = new System.Windows.Forms.PictureBox();
            this.pictureBox133 = new System.Windows.Forms.PictureBox();
            this.pictureBox134 = new System.Windows.Forms.PictureBox();
            this.pictureBox135 = new System.Windows.Forms.PictureBox();
            this.pictureBox136 = new System.Windows.Forms.PictureBox();
            this.pictureBox137 = new System.Windows.Forms.PictureBox();
            this.pictureBox138 = new System.Windows.Forms.PictureBox();
            this.pictureBox139 = new System.Windows.Forms.PictureBox();
            this.pictureBox140 = new System.Windows.Forms.PictureBox();
            this.pictureBox141 = new System.Windows.Forms.PictureBox();
            this.pictureBox142 = new System.Windows.Forms.PictureBox();
            this.pictureBox143 = new System.Windows.Forms.PictureBox();
            this.pictureBox144 = new System.Windows.Forms.PictureBox();
            this.pictureBox145 = new System.Windows.Forms.PictureBox();
            this.pictureBox146 = new System.Windows.Forms.PictureBox();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.pictureBox147 = new System.Windows.Forms.PictureBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.pictureBox148 = new System.Windows.Forms.PictureBox();
            this.pictureBox149 = new System.Windows.Forms.PictureBox();
            this.pictureBox150 = new System.Windows.Forms.PictureBox();
            this.pictureBox151 = new System.Windows.Forms.PictureBox();
            this.pictureBox152 = new System.Windows.Forms.PictureBox();
            this.pictureBox153 = new System.Windows.Forms.PictureBox();
            this.pictureBox154 = new System.Windows.Forms.PictureBox();
            this.label47 = new System.Windows.Forms.Label();
            this.pictureBox155 = new System.Windows.Forms.PictureBox();
            this.pictureBox156 = new System.Windows.Forms.PictureBox();
            this.pictureBox157 = new System.Windows.Forms.PictureBox();
            this.pictureBox158 = new System.Windows.Forms.PictureBox();
            this.pictureBox159 = new System.Windows.Forms.PictureBox();
            this.pictureBox160 = new System.Windows.Forms.PictureBox();
            this.pictureBox161 = new System.Windows.Forms.PictureBox();
            this.pictureBox162 = new System.Windows.Forms.PictureBox();
            this.pictureBox163 = new System.Windows.Forms.PictureBox();
            this.pictureBox164 = new System.Windows.Forms.PictureBox();
            this.pictureBox165 = new System.Windows.Forms.PictureBox();
            this.pictureBox166 = new System.Windows.Forms.PictureBox();
            this.pictureBox167 = new System.Windows.Forms.PictureBox();
            this.pictureBox168 = new System.Windows.Forms.PictureBox();
            this.pictureBox169 = new System.Windows.Forms.PictureBox();
            this.pictureBox170 = new System.Windows.Forms.PictureBox();
            this.pictureBox171 = new System.Windows.Forms.PictureBox();
            this.pictureBox172 = new System.Windows.Forms.PictureBox();
            this.pictureBox173 = new System.Windows.Forms.PictureBox();
            this.pictureBox174 = new System.Windows.Forms.PictureBox();
            this.pictureBox175 = new System.Windows.Forms.PictureBox();
            this.pictureBox176 = new System.Windows.Forms.PictureBox();
            this.pictureBox177 = new System.Windows.Forms.PictureBox();
            this.pictureBox178 = new System.Windows.Forms.PictureBox();
            this.pictureBox179 = new System.Windows.Forms.PictureBox();
            this.pictureBox180 = new System.Windows.Forms.PictureBox();
            this.pictureBox181 = new System.Windows.Forms.PictureBox();
            this.pictureBox182 = new System.Windows.Forms.PictureBox();
            this.pictureBox183 = new System.Windows.Forms.PictureBox();
            this.pictureBox184 = new System.Windows.Forms.PictureBox();
            this.pictureBox185 = new System.Windows.Forms.PictureBox();
            this.pictureBox186 = new System.Windows.Forms.PictureBox();
            this.pictureBox187 = new System.Windows.Forms.PictureBox();
            this.pictureBox188 = new System.Windows.Forms.PictureBox();
            this.pictureBox189 = new System.Windows.Forms.PictureBox();
            this.pictureBox190 = new System.Windows.Forms.PictureBox();
            this.pictureBox191 = new System.Windows.Forms.PictureBox();
            this.pictureBox192 = new System.Windows.Forms.PictureBox();
            this.pictureBox193 = new System.Windows.Forms.PictureBox();
            this.pictureBox194 = new System.Windows.Forms.PictureBox();
            this.pictureBox195 = new System.Windows.Forms.PictureBox();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.pictureBox196 = new System.Windows.Forms.PictureBox();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.pictureBox197 = new System.Windows.Forms.PictureBox();
            this.pictureBox198 = new System.Windows.Forms.PictureBox();
            this.pictureBox199 = new System.Windows.Forms.PictureBox();
            this.pictureBox200 = new System.Windows.Forms.PictureBox();
            this.pictureBox201 = new System.Windows.Forms.PictureBox();
            this.pictureBox202 = new System.Windows.Forms.PictureBox();
            this.pictureBox203 = new System.Windows.Forms.PictureBox();
            this.label61 = new System.Windows.Forms.Label();
            this.pictureBox204 = new System.Windows.Forms.PictureBox();
            this.pictureBox205 = new System.Windows.Forms.PictureBox();
            this.pictureBox206 = new System.Windows.Forms.PictureBox();
            this.pictureBox207 = new System.Windows.Forms.PictureBox();
            this.pictureBox208 = new System.Windows.Forms.PictureBox();
            this.pictureBox209 = new System.Windows.Forms.PictureBox();
            this.pictureBox210 = new System.Windows.Forms.PictureBox();
            this.pictureBox211 = new System.Windows.Forms.PictureBox();
            this.pictureBox212 = new System.Windows.Forms.PictureBox();
            this.pictureBox213 = new System.Windows.Forms.PictureBox();
            this.pictureBox214 = new System.Windows.Forms.PictureBox();
            this.pictureBox215 = new System.Windows.Forms.PictureBox();
            this.pictureBox216 = new System.Windows.Forms.PictureBox();
            this.pictureBox217 = new System.Windows.Forms.PictureBox();
            this.pictureBox218 = new System.Windows.Forms.PictureBox();
            this.pictureBox219 = new System.Windows.Forms.PictureBox();
            this.pictureBox220 = new System.Windows.Forms.PictureBox();
            this.pictureBox221 = new System.Windows.Forms.PictureBox();
            this.pictureBox222 = new System.Windows.Forms.PictureBox();
            this.pictureBox223 = new System.Windows.Forms.PictureBox();
            this.pictureBox224 = new System.Windows.Forms.PictureBox();
            this.pictureBox225 = new System.Windows.Forms.PictureBox();
            this.pictureBox226 = new System.Windows.Forms.PictureBox();
            this.pictureBox227 = new System.Windows.Forms.PictureBox();
            this.pictureBox228 = new System.Windows.Forms.PictureBox();
            this.pictureBox229 = new System.Windows.Forms.PictureBox();
            this.pictureBox230 = new System.Windows.Forms.PictureBox();
            this.pictureBox231 = new System.Windows.Forms.PictureBox();
            this.pictureBox232 = new System.Windows.Forms.PictureBox();
            this.pictureBox233 = new System.Windows.Forms.PictureBox();
            this.pictureBox234 = new System.Windows.Forms.PictureBox();
            this.pictureBox235 = new System.Windows.Forms.PictureBox();
            this.pictureBox236 = new System.Windows.Forms.PictureBox();
            this.pictureBox237 = new System.Windows.Forms.PictureBox();
            this.pictureBox238 = new System.Windows.Forms.PictureBox();
            this.pictureBox239 = new System.Windows.Forms.PictureBox();
            this.pictureBox240 = new System.Windows.Forms.PictureBox();
            this.pictureBox241 = new System.Windows.Forms.PictureBox();
            this.pictureBox242 = new System.Windows.Forms.PictureBox();
            this.pictureBox243 = new System.Windows.Forms.PictureBox();
            this.pictureBox244 = new System.Windows.Forms.PictureBox();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.pictureBox245 = new System.Windows.Forms.PictureBox();
            this.tbFloorWashroom = new System.Windows.Forms.TextBox();
            this.dtpicker_TimeWash = new System.Windows.Forms.DateTimePicker();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox30)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox35)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox36)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox37)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox38)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox39)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox40)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox41)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox42)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox43)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox44)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox45)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox46)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox47)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox48)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox49)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox50)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox51)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox52)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox53)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox54)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox55)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox56)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox57)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox58)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox59)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox60)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox61)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox62)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox63)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox64)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox65)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox66)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox67)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox68)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox69)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox70)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox71)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox72)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox73)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox74)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox75)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox76)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox77)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox78)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox79)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox80)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox81)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox82)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox83)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox84)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox85)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox86)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox87)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox88)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox89)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox90)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox91)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox92)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox93)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox94)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox95)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox96)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox97)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox98)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox99)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox100)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox101)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox102)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox103)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox104)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox105)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox106)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox107)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox108)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox109)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox110)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox111)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox112)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox113)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox114)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox115)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox116)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox117)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox118)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox119)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox120)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox121)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox122)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox123)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox124)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox125)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox126)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox127)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox128)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox129)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox130)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox131)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox132)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox133)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox134)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox135)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox136)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox137)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox138)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox139)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox140)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox141)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox142)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox143)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox144)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox145)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox146)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox147)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox148)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox149)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox150)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox151)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox152)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox153)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox154)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox155)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox156)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox157)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox158)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox159)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox160)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox161)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox162)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox163)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox164)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox165)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox166)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox167)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox168)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox169)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox170)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox171)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox172)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox173)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox174)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox175)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox176)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox177)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox178)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox179)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox180)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox181)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox182)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox183)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox184)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox185)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox186)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox187)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox188)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox189)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox190)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox191)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox192)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox193)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox194)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox195)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox196)).BeginInit();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox197)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox198)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox199)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox200)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox201)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox202)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox203)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox204)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox205)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox206)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox207)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox208)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox209)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox210)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox211)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox212)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox213)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox214)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox215)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox216)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox217)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox218)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox219)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox220)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox221)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox222)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox223)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox224)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox225)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox226)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox227)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox228)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox229)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox230)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox231)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox232)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox233)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox234)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox235)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox236)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox237)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox238)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox239)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox240)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox241)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox242)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox243)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox244)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox245)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.tabControl1);
            this.groupBox1.Location = new System.Drawing.Point(31, 29);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Size = new System.Drawing.Size(546, 301);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Washing Machines Schedule";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dtpicker_TimeWash);
            this.groupBox2.Controls.Add(this.tbFloorWashroom);
            this.groupBox2.Controls.Add(this.button1);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.dtpicker_DateWash);
            this.groupBox2.Location = new System.Drawing.Point(318, 54);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox2.Size = new System.Drawing.Size(224, 172);
            this.groupBox2.TabIndex = 18;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Select";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(157, 127);
            this.button1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(56, 32);
            this.button1.TabIndex = 31;
            this.button1.Text = "Apply";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(31, 105);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(30, 13);
            this.label5.TabIndex = 29;
            this.label5.Text = "Floor";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(31, 71);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 13);
            this.label2.TabIndex = 27;
            this.label2.Text = "Time";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(31, 35);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 13);
            this.label1.TabIndex = 26;
            this.label1.Text = "Date";
            // 
            // dtpicker_DateWash
            // 
            this.dtpicker_DateWash.Location = new System.Drawing.Point(66, 29);
            this.dtpicker_DateWash.Name = "dtpicker_DateWash";
            this.dtpicker_DateWash.Size = new System.Drawing.Size(147, 20);
            this.dtpicker_DateWash.TabIndex = 25;
            this.dtpicker_DateWash.Value = new System.DateTime(2023, 4, 21, 12, 28, 50, 0);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Location = new System.Drawing.Point(15, 29);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(285, 254);
            this.tabControl1.TabIndex = 17;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.pictureBox1);
            this.tabPage1.Controls.Add(this.pictureBox2);
            this.tabPage1.Controls.Add(this.pictureBox3);
            this.tabPage1.Controls.Add(this.pictureBox4);
            this.tabPage1.Controls.Add(this.pictureBox5);
            this.tabPage1.Controls.Add(this.pictureBox6);
            this.tabPage1.Controls.Add(this.pictureBox7);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.pictureBox8);
            this.tabPage1.Controls.Add(this.pictureBox9);
            this.tabPage1.Controls.Add(this.pictureBox10);
            this.tabPage1.Controls.Add(this.pictureBox11);
            this.tabPage1.Controls.Add(this.pictureBox12);
            this.tabPage1.Controls.Add(this.pictureBox13);
            this.tabPage1.Controls.Add(this.pictureBox14);
            this.tabPage1.Controls.Add(this.pictureBox15);
            this.tabPage1.Controls.Add(this.pictureBox16);
            this.tabPage1.Controls.Add(this.pictureBox17);
            this.tabPage1.Controls.Add(this.pictureBox18);
            this.tabPage1.Controls.Add(this.pictureBox19);
            this.tabPage1.Controls.Add(this.pictureBox20);
            this.tabPage1.Controls.Add(this.pictureBox21);
            this.tabPage1.Controls.Add(this.pictureBox22);
            this.tabPage1.Controls.Add(this.pictureBox23);
            this.tabPage1.Controls.Add(this.pictureBox24);
            this.tabPage1.Controls.Add(this.pictureBox25);
            this.tabPage1.Controls.Add(this.pictureBox26);
            this.tabPage1.Controls.Add(this.pictureBox27);
            this.tabPage1.Controls.Add(this.pictureBox28);
            this.tabPage1.Controls.Add(this.pictureBox29);
            this.tabPage1.Controls.Add(this.pictureBox30);
            this.tabPage1.Controls.Add(this.pictureBox31);
            this.tabPage1.Controls.Add(this.pictureBox32);
            this.tabPage1.Controls.Add(this.pictureBox33);
            this.tabPage1.Controls.Add(this.pictureBox34);
            this.tabPage1.Controls.Add(this.pictureBox35);
            this.tabPage1.Controls.Add(this.pictureBox36);
            this.tabPage1.Controls.Add(this.pictureBox37);
            this.tabPage1.Controls.Add(this.pictureBox38);
            this.tabPage1.Controls.Add(this.pictureBox39);
            this.tabPage1.Controls.Add(this.pictureBox40);
            this.tabPage1.Controls.Add(this.pictureBox41);
            this.tabPage1.Controls.Add(this.pictureBox42);
            this.tabPage1.Controls.Add(this.pictureBox43);
            this.tabPage1.Controls.Add(this.pictureBox44);
            this.tabPage1.Controls.Add(this.pictureBox45);
            this.tabPage1.Controls.Add(this.pictureBox46);
            this.tabPage1.Controls.Add(this.pictureBox47);
            this.tabPage1.Controls.Add(this.pictureBox48);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Controls.Add(this.label11);
            this.tabPage1.Controls.Add(this.label12);
            this.tabPage1.Controls.Add(this.label13);
            this.tabPage1.Controls.Add(this.label14);
            this.tabPage1.Controls.Add(this.label15);
            this.tabPage1.Controls.Add(this.label16);
            this.tabPage1.Controls.Add(this.label17);
            this.tabPage1.Controls.Add(this.label18);
            this.tabPage1.Controls.Add(this.label19);
            this.tabPage1.Controls.Add(this.pictureBox49);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3, 3, 3, 3);
            this.tabPage1.Size = new System.Drawing.Size(277, 228);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "1st floor";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(254, 177);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(14, 15);
            this.pictureBox1.TabIndex = 199;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(226, 177);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(14, 15);
            this.pictureBox2.TabIndex = 198;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Location = new System.Drawing.Point(197, 179);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(14, 15);
            this.pictureBox3.TabIndex = 197;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Location = new System.Drawing.Point(168, 177);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(14, 15);
            this.pictureBox4.TabIndex = 196;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Location = new System.Drawing.Point(139, 179);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(14, 15);
            this.pictureBox5.TabIndex = 195;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Location = new System.Drawing.Point(106, 177);
            this.pictureBox6.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(14, 15);
            this.pictureBox6.TabIndex = 194;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Location = new System.Drawing.Point(77, 179);
            this.pictureBox7.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(14, 15);
            this.pictureBox7.TabIndex = 193;
            this.pictureBox7.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(13, 184);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(64, 13);
            this.label6.TabIndex = 192;
            this.label6.Text = "20:00-22:00";
            // 
            // pictureBox8
            // 
            this.pictureBox8.Location = new System.Drawing.Point(254, 158);
            this.pictureBox8.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(14, 15);
            this.pictureBox8.TabIndex = 191;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Location = new System.Drawing.Point(254, 138);
            this.pictureBox9.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(14, 15);
            this.pictureBox9.TabIndex = 190;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Location = new System.Drawing.Point(254, 116);
            this.pictureBox10.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(14, 15);
            this.pictureBox10.TabIndex = 189;
            this.pictureBox10.TabStop = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.Location = new System.Drawing.Point(254, 93);
            this.pictureBox11.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(14, 15);
            this.pictureBox11.TabIndex = 188;
            this.pictureBox11.TabStop = false;
            // 
            // pictureBox12
            // 
            this.pictureBox12.Location = new System.Drawing.Point(254, 74);
            this.pictureBox12.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(14, 15);
            this.pictureBox12.TabIndex = 187;
            this.pictureBox12.TabStop = false;
            // 
            // pictureBox13
            // 
            this.pictureBox13.Location = new System.Drawing.Point(254, 53);
            this.pictureBox13.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(14, 15);
            this.pictureBox13.TabIndex = 186;
            this.pictureBox13.TabStop = false;
            // 
            // pictureBox14
            // 
            this.pictureBox14.Location = new System.Drawing.Point(226, 158);
            this.pictureBox14.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(14, 15);
            this.pictureBox14.TabIndex = 185;
            this.pictureBox14.TabStop = false;
            // 
            // pictureBox15
            // 
            this.pictureBox15.Location = new System.Drawing.Point(226, 138);
            this.pictureBox15.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(14, 15);
            this.pictureBox15.TabIndex = 184;
            this.pictureBox15.TabStop = false;
            // 
            // pictureBox16
            // 
            this.pictureBox16.Location = new System.Drawing.Point(226, 116);
            this.pictureBox16.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(14, 15);
            this.pictureBox16.TabIndex = 183;
            this.pictureBox16.TabStop = false;
            // 
            // pictureBox17
            // 
            this.pictureBox17.Location = new System.Drawing.Point(226, 93);
            this.pictureBox17.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox17.Name = "pictureBox17";
            this.pictureBox17.Size = new System.Drawing.Size(14, 15);
            this.pictureBox17.TabIndex = 182;
            this.pictureBox17.TabStop = false;
            // 
            // pictureBox18
            // 
            this.pictureBox18.Location = new System.Drawing.Point(226, 74);
            this.pictureBox18.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox18.Name = "pictureBox18";
            this.pictureBox18.Size = new System.Drawing.Size(14, 15);
            this.pictureBox18.TabIndex = 181;
            this.pictureBox18.TabStop = false;
            // 
            // pictureBox19
            // 
            this.pictureBox19.Location = new System.Drawing.Point(226, 53);
            this.pictureBox19.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox19.Name = "pictureBox19";
            this.pictureBox19.Size = new System.Drawing.Size(14, 15);
            this.pictureBox19.TabIndex = 180;
            this.pictureBox19.TabStop = false;
            // 
            // pictureBox20
            // 
            this.pictureBox20.Location = new System.Drawing.Point(197, 159);
            this.pictureBox20.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox20.Name = "pictureBox20";
            this.pictureBox20.Size = new System.Drawing.Size(14, 15);
            this.pictureBox20.TabIndex = 179;
            this.pictureBox20.TabStop = false;
            // 
            // pictureBox21
            // 
            this.pictureBox21.Location = new System.Drawing.Point(197, 138);
            this.pictureBox21.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox21.Name = "pictureBox21";
            this.pictureBox21.Size = new System.Drawing.Size(14, 15);
            this.pictureBox21.TabIndex = 178;
            this.pictureBox21.TabStop = false;
            // 
            // pictureBox22
            // 
            this.pictureBox22.Location = new System.Drawing.Point(197, 116);
            this.pictureBox22.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox22.Name = "pictureBox22";
            this.pictureBox22.Size = new System.Drawing.Size(14, 15);
            this.pictureBox22.TabIndex = 177;
            this.pictureBox22.TabStop = false;
            // 
            // pictureBox23
            // 
            this.pictureBox23.Location = new System.Drawing.Point(197, 93);
            this.pictureBox23.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox23.Name = "pictureBox23";
            this.pictureBox23.Size = new System.Drawing.Size(14, 15);
            this.pictureBox23.TabIndex = 176;
            this.pictureBox23.TabStop = false;
            // 
            // pictureBox24
            // 
            this.pictureBox24.Location = new System.Drawing.Point(197, 74);
            this.pictureBox24.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox24.Name = "pictureBox24";
            this.pictureBox24.Size = new System.Drawing.Size(14, 15);
            this.pictureBox24.TabIndex = 175;
            this.pictureBox24.TabStop = false;
            // 
            // pictureBox25
            // 
            this.pictureBox25.Location = new System.Drawing.Point(197, 53);
            this.pictureBox25.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox25.Name = "pictureBox25";
            this.pictureBox25.Size = new System.Drawing.Size(14, 15);
            this.pictureBox25.TabIndex = 174;
            this.pictureBox25.TabStop = false;
            // 
            // pictureBox26
            // 
            this.pictureBox26.Location = new System.Drawing.Point(168, 158);
            this.pictureBox26.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox26.Name = "pictureBox26";
            this.pictureBox26.Size = new System.Drawing.Size(14, 15);
            this.pictureBox26.TabIndex = 173;
            this.pictureBox26.TabStop = false;
            // 
            // pictureBox27
            // 
            this.pictureBox27.Location = new System.Drawing.Point(168, 138);
            this.pictureBox27.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox27.Name = "pictureBox27";
            this.pictureBox27.Size = new System.Drawing.Size(14, 15);
            this.pictureBox27.TabIndex = 172;
            this.pictureBox27.TabStop = false;
            // 
            // pictureBox28
            // 
            this.pictureBox28.Location = new System.Drawing.Point(168, 116);
            this.pictureBox28.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox28.Name = "pictureBox28";
            this.pictureBox28.Size = new System.Drawing.Size(14, 15);
            this.pictureBox28.TabIndex = 171;
            this.pictureBox28.TabStop = false;
            // 
            // pictureBox29
            // 
            this.pictureBox29.Location = new System.Drawing.Point(168, 93);
            this.pictureBox29.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox29.Name = "pictureBox29";
            this.pictureBox29.Size = new System.Drawing.Size(14, 15);
            this.pictureBox29.TabIndex = 170;
            this.pictureBox29.TabStop = false;
            // 
            // pictureBox30
            // 
            this.pictureBox30.Location = new System.Drawing.Point(168, 74);
            this.pictureBox30.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox30.Name = "pictureBox30";
            this.pictureBox30.Size = new System.Drawing.Size(14, 15);
            this.pictureBox30.TabIndex = 169;
            this.pictureBox30.TabStop = false;
            // 
            // pictureBox31
            // 
            this.pictureBox31.Location = new System.Drawing.Point(168, 53);
            this.pictureBox31.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox31.Name = "pictureBox31";
            this.pictureBox31.Size = new System.Drawing.Size(14, 15);
            this.pictureBox31.TabIndex = 168;
            this.pictureBox31.TabStop = false;
            // 
            // pictureBox32
            // 
            this.pictureBox32.Location = new System.Drawing.Point(139, 159);
            this.pictureBox32.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox32.Name = "pictureBox32";
            this.pictureBox32.Size = new System.Drawing.Size(14, 15);
            this.pictureBox32.TabIndex = 167;
            this.pictureBox32.TabStop = false;
            // 
            // pictureBox33
            // 
            this.pictureBox33.Location = new System.Drawing.Point(139, 138);
            this.pictureBox33.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox33.Name = "pictureBox33";
            this.pictureBox33.Size = new System.Drawing.Size(14, 15);
            this.pictureBox33.TabIndex = 166;
            this.pictureBox33.TabStop = false;
            // 
            // pictureBox34
            // 
            this.pictureBox34.Location = new System.Drawing.Point(139, 116);
            this.pictureBox34.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox34.Name = "pictureBox34";
            this.pictureBox34.Size = new System.Drawing.Size(14, 15);
            this.pictureBox34.TabIndex = 165;
            this.pictureBox34.TabStop = false;
            // 
            // pictureBox35
            // 
            this.pictureBox35.Location = new System.Drawing.Point(139, 93);
            this.pictureBox35.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox35.Name = "pictureBox35";
            this.pictureBox35.Size = new System.Drawing.Size(14, 15);
            this.pictureBox35.TabIndex = 164;
            this.pictureBox35.TabStop = false;
            // 
            // pictureBox36
            // 
            this.pictureBox36.Location = new System.Drawing.Point(139, 74);
            this.pictureBox36.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox36.Name = "pictureBox36";
            this.pictureBox36.Size = new System.Drawing.Size(14, 15);
            this.pictureBox36.TabIndex = 163;
            this.pictureBox36.TabStop = false;
            // 
            // pictureBox37
            // 
            this.pictureBox37.Location = new System.Drawing.Point(139, 53);
            this.pictureBox37.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox37.Name = "pictureBox37";
            this.pictureBox37.Size = new System.Drawing.Size(14, 15);
            this.pictureBox37.TabIndex = 162;
            this.pictureBox37.TabStop = false;
            // 
            // pictureBox38
            // 
            this.pictureBox38.Location = new System.Drawing.Point(106, 158);
            this.pictureBox38.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox38.Name = "pictureBox38";
            this.pictureBox38.Size = new System.Drawing.Size(14, 15);
            this.pictureBox38.TabIndex = 161;
            this.pictureBox38.TabStop = false;
            // 
            // pictureBox39
            // 
            this.pictureBox39.Location = new System.Drawing.Point(106, 138);
            this.pictureBox39.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox39.Name = "pictureBox39";
            this.pictureBox39.Size = new System.Drawing.Size(14, 15);
            this.pictureBox39.TabIndex = 160;
            this.pictureBox39.TabStop = false;
            // 
            // pictureBox40
            // 
            this.pictureBox40.Location = new System.Drawing.Point(106, 116);
            this.pictureBox40.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox40.Name = "pictureBox40";
            this.pictureBox40.Size = new System.Drawing.Size(14, 15);
            this.pictureBox40.TabIndex = 159;
            this.pictureBox40.TabStop = false;
            // 
            // pictureBox41
            // 
            this.pictureBox41.Location = new System.Drawing.Point(106, 93);
            this.pictureBox41.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox41.Name = "pictureBox41";
            this.pictureBox41.Size = new System.Drawing.Size(14, 15);
            this.pictureBox41.TabIndex = 158;
            this.pictureBox41.TabStop = false;
            // 
            // pictureBox42
            // 
            this.pictureBox42.Location = new System.Drawing.Point(106, 74);
            this.pictureBox42.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox42.Name = "pictureBox42";
            this.pictureBox42.Size = new System.Drawing.Size(14, 15);
            this.pictureBox42.TabIndex = 157;
            this.pictureBox42.TabStop = false;
            // 
            // pictureBox43
            // 
            this.pictureBox43.Location = new System.Drawing.Point(106, 53);
            this.pictureBox43.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox43.Name = "pictureBox43";
            this.pictureBox43.Size = new System.Drawing.Size(14, 15);
            this.pictureBox43.TabIndex = 156;
            this.pictureBox43.TabStop = false;
            // 
            // pictureBox44
            // 
            this.pictureBox44.Location = new System.Drawing.Point(77, 159);
            this.pictureBox44.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox44.Name = "pictureBox44";
            this.pictureBox44.Size = new System.Drawing.Size(14, 15);
            this.pictureBox44.TabIndex = 155;
            this.pictureBox44.TabStop = false;
            // 
            // pictureBox45
            // 
            this.pictureBox45.Location = new System.Drawing.Point(77, 138);
            this.pictureBox45.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox45.Name = "pictureBox45";
            this.pictureBox45.Size = new System.Drawing.Size(14, 15);
            this.pictureBox45.TabIndex = 154;
            this.pictureBox45.TabStop = false;
            // 
            // pictureBox46
            // 
            this.pictureBox46.Location = new System.Drawing.Point(77, 116);
            this.pictureBox46.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox46.Name = "pictureBox46";
            this.pictureBox46.Size = new System.Drawing.Size(14, 15);
            this.pictureBox46.TabIndex = 153;
            this.pictureBox46.TabStop = false;
            // 
            // pictureBox47
            // 
            this.pictureBox47.Location = new System.Drawing.Point(77, 93);
            this.pictureBox47.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox47.Name = "pictureBox47";
            this.pictureBox47.Size = new System.Drawing.Size(14, 15);
            this.pictureBox47.TabIndex = 152;
            this.pictureBox47.TabStop = false;
            // 
            // pictureBox48
            // 
            this.pictureBox48.Location = new System.Drawing.Point(77, 74);
            this.pictureBox48.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox48.Name = "pictureBox48";
            this.pictureBox48.Size = new System.Drawing.Size(14, 15);
            this.pictureBox48.TabIndex = 151;
            this.pictureBox48.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(13, 159);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(64, 13);
            this.label7.TabIndex = 150;
            this.label7.Text = "18:00-20:00";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(13, 138);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(64, 13);
            this.label8.TabIndex = 149;
            this.label8.Text = "16:00-18:00";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(13, 116);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(64, 13);
            this.label9.TabIndex = 148;
            this.label9.Text = "14:00-16:00";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(13, 93);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(64, 13);
            this.label10.TabIndex = 147;
            this.label10.Text = "12:00-14:00";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(13, 74);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(64, 13);
            this.label11.TabIndex = 146;
            this.label11.Text = "10:00-12:00";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(18, 54);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(58, 13);
            this.label12.TabIndex = 145;
            this.label12.Text = "8:00-10:00";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(244, 32);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(26, 13);
            this.label13.TabIndex = 144;
            this.label13.Text = "Sun";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(220, 32);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(23, 13);
            this.label14.TabIndex = 143;
            this.label14.Text = "Sat";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(199, 32);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(18, 13);
            this.label15.TabIndex = 142;
            this.label15.Text = "Fri";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(164, 32);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(34, 13);
            this.label16.TabIndex = 141;
            this.label16.Text = "Thurs";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(132, 32);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(30, 13);
            this.label17.TabIndex = 140;
            this.label17.Text = "Wed";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(104, 32);
            this.label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(26, 13);
            this.label18.TabIndex = 139;
            this.label18.Text = "Tue";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(75, 32);
            this.label19.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(28, 13);
            this.label19.TabIndex = 138;
            this.label19.Text = "Mon";
            // 
            // pictureBox49
            // 
            this.pictureBox49.Location = new System.Drawing.Point(77, 53);
            this.pictureBox49.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox49.Name = "pictureBox49";
            this.pictureBox49.Size = new System.Drawing.Size(14, 15);
            this.pictureBox49.TabIndex = 137;
            this.pictureBox49.TabStop = false;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.pictureBox50);
            this.tabPage2.Controls.Add(this.pictureBox51);
            this.tabPage2.Controls.Add(this.pictureBox52);
            this.tabPage2.Controls.Add(this.pictureBox53);
            this.tabPage2.Controls.Add(this.pictureBox54);
            this.tabPage2.Controls.Add(this.pictureBox55);
            this.tabPage2.Controls.Add(this.pictureBox56);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.pictureBox57);
            this.tabPage2.Controls.Add(this.pictureBox58);
            this.tabPage2.Controls.Add(this.pictureBox59);
            this.tabPage2.Controls.Add(this.pictureBox60);
            this.tabPage2.Controls.Add(this.pictureBox61);
            this.tabPage2.Controls.Add(this.pictureBox62);
            this.tabPage2.Controls.Add(this.pictureBox63);
            this.tabPage2.Controls.Add(this.pictureBox64);
            this.tabPage2.Controls.Add(this.pictureBox65);
            this.tabPage2.Controls.Add(this.pictureBox66);
            this.tabPage2.Controls.Add(this.pictureBox67);
            this.tabPage2.Controls.Add(this.pictureBox68);
            this.tabPage2.Controls.Add(this.pictureBox69);
            this.tabPage2.Controls.Add(this.pictureBox70);
            this.tabPage2.Controls.Add(this.pictureBox71);
            this.tabPage2.Controls.Add(this.pictureBox72);
            this.tabPage2.Controls.Add(this.pictureBox73);
            this.tabPage2.Controls.Add(this.pictureBox74);
            this.tabPage2.Controls.Add(this.pictureBox75);
            this.tabPage2.Controls.Add(this.pictureBox76);
            this.tabPage2.Controls.Add(this.pictureBox77);
            this.tabPage2.Controls.Add(this.pictureBox78);
            this.tabPage2.Controls.Add(this.pictureBox79);
            this.tabPage2.Controls.Add(this.pictureBox80);
            this.tabPage2.Controls.Add(this.pictureBox81);
            this.tabPage2.Controls.Add(this.pictureBox82);
            this.tabPage2.Controls.Add(this.pictureBox83);
            this.tabPage2.Controls.Add(this.pictureBox84);
            this.tabPage2.Controls.Add(this.pictureBox85);
            this.tabPage2.Controls.Add(this.pictureBox86);
            this.tabPage2.Controls.Add(this.pictureBox87);
            this.tabPage2.Controls.Add(this.pictureBox88);
            this.tabPage2.Controls.Add(this.pictureBox89);
            this.tabPage2.Controls.Add(this.pictureBox90);
            this.tabPage2.Controls.Add(this.pictureBox91);
            this.tabPage2.Controls.Add(this.pictureBox92);
            this.tabPage2.Controls.Add(this.pictureBox93);
            this.tabPage2.Controls.Add(this.pictureBox94);
            this.tabPage2.Controls.Add(this.pictureBox95);
            this.tabPage2.Controls.Add(this.pictureBox96);
            this.tabPage2.Controls.Add(this.pictureBox97);
            this.tabPage2.Controls.Add(this.label20);
            this.tabPage2.Controls.Add(this.label21);
            this.tabPage2.Controls.Add(this.label22);
            this.tabPage2.Controls.Add(this.label23);
            this.tabPage2.Controls.Add(this.label24);
            this.tabPage2.Controls.Add(this.label25);
            this.tabPage2.Controls.Add(this.label26);
            this.tabPage2.Controls.Add(this.label27);
            this.tabPage2.Controls.Add(this.label28);
            this.tabPage2.Controls.Add(this.label29);
            this.tabPage2.Controls.Add(this.label30);
            this.tabPage2.Controls.Add(this.label31);
            this.tabPage2.Controls.Add(this.label32);
            this.tabPage2.Controls.Add(this.pictureBox98);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3, 3, 3, 3);
            this.tabPage2.Size = new System.Drawing.Size(277, 228);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "2nd floor";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // pictureBox50
            // 
            this.pictureBox50.Location = new System.Drawing.Point(254, 177);
            this.pictureBox50.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox50.Name = "pictureBox50";
            this.pictureBox50.Size = new System.Drawing.Size(14, 15);
            this.pictureBox50.TabIndex = 199;
            this.pictureBox50.TabStop = false;
            // 
            // pictureBox51
            // 
            this.pictureBox51.Location = new System.Drawing.Point(226, 177);
            this.pictureBox51.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox51.Name = "pictureBox51";
            this.pictureBox51.Size = new System.Drawing.Size(14, 15);
            this.pictureBox51.TabIndex = 198;
            this.pictureBox51.TabStop = false;
            // 
            // pictureBox52
            // 
            this.pictureBox52.Location = new System.Drawing.Point(197, 179);
            this.pictureBox52.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox52.Name = "pictureBox52";
            this.pictureBox52.Size = new System.Drawing.Size(14, 15);
            this.pictureBox52.TabIndex = 197;
            this.pictureBox52.TabStop = false;
            // 
            // pictureBox53
            // 
            this.pictureBox53.Location = new System.Drawing.Point(168, 177);
            this.pictureBox53.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox53.Name = "pictureBox53";
            this.pictureBox53.Size = new System.Drawing.Size(14, 15);
            this.pictureBox53.TabIndex = 196;
            this.pictureBox53.TabStop = false;
            // 
            // pictureBox54
            // 
            this.pictureBox54.Location = new System.Drawing.Point(139, 179);
            this.pictureBox54.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox54.Name = "pictureBox54";
            this.pictureBox54.Size = new System.Drawing.Size(14, 15);
            this.pictureBox54.TabIndex = 195;
            this.pictureBox54.TabStop = false;
            // 
            // pictureBox55
            // 
            this.pictureBox55.Location = new System.Drawing.Point(106, 177);
            this.pictureBox55.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox55.Name = "pictureBox55";
            this.pictureBox55.Size = new System.Drawing.Size(14, 15);
            this.pictureBox55.TabIndex = 194;
            this.pictureBox55.TabStop = false;
            // 
            // pictureBox56
            // 
            this.pictureBox56.Location = new System.Drawing.Point(77, 179);
            this.pictureBox56.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox56.Name = "pictureBox56";
            this.pictureBox56.Size = new System.Drawing.Size(14, 15);
            this.pictureBox56.TabIndex = 193;
            this.pictureBox56.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 184);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 13);
            this.label4.TabIndex = 192;
            this.label4.Text = "20:00-22:00";
            // 
            // pictureBox57
            // 
            this.pictureBox57.Location = new System.Drawing.Point(254, 158);
            this.pictureBox57.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox57.Name = "pictureBox57";
            this.pictureBox57.Size = new System.Drawing.Size(14, 15);
            this.pictureBox57.TabIndex = 191;
            this.pictureBox57.TabStop = false;
            // 
            // pictureBox58
            // 
            this.pictureBox58.Location = new System.Drawing.Point(254, 138);
            this.pictureBox58.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox58.Name = "pictureBox58";
            this.pictureBox58.Size = new System.Drawing.Size(14, 15);
            this.pictureBox58.TabIndex = 190;
            this.pictureBox58.TabStop = false;
            // 
            // pictureBox59
            // 
            this.pictureBox59.Location = new System.Drawing.Point(254, 116);
            this.pictureBox59.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox59.Name = "pictureBox59";
            this.pictureBox59.Size = new System.Drawing.Size(14, 15);
            this.pictureBox59.TabIndex = 189;
            this.pictureBox59.TabStop = false;
            // 
            // pictureBox60
            // 
            this.pictureBox60.Location = new System.Drawing.Point(254, 93);
            this.pictureBox60.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox60.Name = "pictureBox60";
            this.pictureBox60.Size = new System.Drawing.Size(14, 15);
            this.pictureBox60.TabIndex = 188;
            this.pictureBox60.TabStop = false;
            // 
            // pictureBox61
            // 
            this.pictureBox61.Location = new System.Drawing.Point(254, 74);
            this.pictureBox61.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox61.Name = "pictureBox61";
            this.pictureBox61.Size = new System.Drawing.Size(14, 15);
            this.pictureBox61.TabIndex = 187;
            this.pictureBox61.TabStop = false;
            // 
            // pictureBox62
            // 
            this.pictureBox62.Location = new System.Drawing.Point(254, 53);
            this.pictureBox62.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox62.Name = "pictureBox62";
            this.pictureBox62.Size = new System.Drawing.Size(14, 15);
            this.pictureBox62.TabIndex = 186;
            this.pictureBox62.TabStop = false;
            // 
            // pictureBox63
            // 
            this.pictureBox63.Location = new System.Drawing.Point(226, 158);
            this.pictureBox63.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox63.Name = "pictureBox63";
            this.pictureBox63.Size = new System.Drawing.Size(14, 15);
            this.pictureBox63.TabIndex = 185;
            this.pictureBox63.TabStop = false;
            // 
            // pictureBox64
            // 
            this.pictureBox64.Location = new System.Drawing.Point(226, 138);
            this.pictureBox64.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox64.Name = "pictureBox64";
            this.pictureBox64.Size = new System.Drawing.Size(14, 15);
            this.pictureBox64.TabIndex = 184;
            this.pictureBox64.TabStop = false;
            // 
            // pictureBox65
            // 
            this.pictureBox65.Location = new System.Drawing.Point(226, 116);
            this.pictureBox65.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox65.Name = "pictureBox65";
            this.pictureBox65.Size = new System.Drawing.Size(14, 15);
            this.pictureBox65.TabIndex = 183;
            this.pictureBox65.TabStop = false;
            // 
            // pictureBox66
            // 
            this.pictureBox66.Location = new System.Drawing.Point(226, 93);
            this.pictureBox66.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox66.Name = "pictureBox66";
            this.pictureBox66.Size = new System.Drawing.Size(14, 15);
            this.pictureBox66.TabIndex = 182;
            this.pictureBox66.TabStop = false;
            // 
            // pictureBox67
            // 
            this.pictureBox67.Location = new System.Drawing.Point(226, 74);
            this.pictureBox67.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox67.Name = "pictureBox67";
            this.pictureBox67.Size = new System.Drawing.Size(14, 15);
            this.pictureBox67.TabIndex = 181;
            this.pictureBox67.TabStop = false;
            // 
            // pictureBox68
            // 
            this.pictureBox68.Location = new System.Drawing.Point(226, 53);
            this.pictureBox68.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox68.Name = "pictureBox68";
            this.pictureBox68.Size = new System.Drawing.Size(14, 15);
            this.pictureBox68.TabIndex = 180;
            this.pictureBox68.TabStop = false;
            // 
            // pictureBox69
            // 
            this.pictureBox69.Location = new System.Drawing.Point(197, 159);
            this.pictureBox69.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox69.Name = "pictureBox69";
            this.pictureBox69.Size = new System.Drawing.Size(14, 15);
            this.pictureBox69.TabIndex = 179;
            this.pictureBox69.TabStop = false;
            // 
            // pictureBox70
            // 
            this.pictureBox70.Location = new System.Drawing.Point(197, 138);
            this.pictureBox70.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox70.Name = "pictureBox70";
            this.pictureBox70.Size = new System.Drawing.Size(14, 15);
            this.pictureBox70.TabIndex = 178;
            this.pictureBox70.TabStop = false;
            // 
            // pictureBox71
            // 
            this.pictureBox71.Location = new System.Drawing.Point(197, 116);
            this.pictureBox71.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox71.Name = "pictureBox71";
            this.pictureBox71.Size = new System.Drawing.Size(14, 15);
            this.pictureBox71.TabIndex = 177;
            this.pictureBox71.TabStop = false;
            // 
            // pictureBox72
            // 
            this.pictureBox72.Location = new System.Drawing.Point(197, 93);
            this.pictureBox72.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox72.Name = "pictureBox72";
            this.pictureBox72.Size = new System.Drawing.Size(14, 15);
            this.pictureBox72.TabIndex = 176;
            this.pictureBox72.TabStop = false;
            // 
            // pictureBox73
            // 
            this.pictureBox73.Location = new System.Drawing.Point(197, 74);
            this.pictureBox73.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox73.Name = "pictureBox73";
            this.pictureBox73.Size = new System.Drawing.Size(14, 15);
            this.pictureBox73.TabIndex = 175;
            this.pictureBox73.TabStop = false;
            // 
            // pictureBox74
            // 
            this.pictureBox74.Location = new System.Drawing.Point(197, 53);
            this.pictureBox74.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox74.Name = "pictureBox74";
            this.pictureBox74.Size = new System.Drawing.Size(14, 15);
            this.pictureBox74.TabIndex = 174;
            this.pictureBox74.TabStop = false;
            // 
            // pictureBox75
            // 
            this.pictureBox75.Location = new System.Drawing.Point(168, 158);
            this.pictureBox75.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox75.Name = "pictureBox75";
            this.pictureBox75.Size = new System.Drawing.Size(14, 15);
            this.pictureBox75.TabIndex = 173;
            this.pictureBox75.TabStop = false;
            // 
            // pictureBox76
            // 
            this.pictureBox76.Location = new System.Drawing.Point(168, 138);
            this.pictureBox76.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox76.Name = "pictureBox76";
            this.pictureBox76.Size = new System.Drawing.Size(14, 15);
            this.pictureBox76.TabIndex = 172;
            this.pictureBox76.TabStop = false;
            // 
            // pictureBox77
            // 
            this.pictureBox77.Location = new System.Drawing.Point(168, 116);
            this.pictureBox77.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox77.Name = "pictureBox77";
            this.pictureBox77.Size = new System.Drawing.Size(14, 15);
            this.pictureBox77.TabIndex = 171;
            this.pictureBox77.TabStop = false;
            // 
            // pictureBox78
            // 
            this.pictureBox78.Location = new System.Drawing.Point(168, 93);
            this.pictureBox78.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox78.Name = "pictureBox78";
            this.pictureBox78.Size = new System.Drawing.Size(14, 15);
            this.pictureBox78.TabIndex = 170;
            this.pictureBox78.TabStop = false;
            // 
            // pictureBox79
            // 
            this.pictureBox79.Location = new System.Drawing.Point(168, 74);
            this.pictureBox79.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox79.Name = "pictureBox79";
            this.pictureBox79.Size = new System.Drawing.Size(14, 15);
            this.pictureBox79.TabIndex = 169;
            this.pictureBox79.TabStop = false;
            // 
            // pictureBox80
            // 
            this.pictureBox80.Location = new System.Drawing.Point(168, 53);
            this.pictureBox80.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox80.Name = "pictureBox80";
            this.pictureBox80.Size = new System.Drawing.Size(14, 15);
            this.pictureBox80.TabIndex = 168;
            this.pictureBox80.TabStop = false;
            // 
            // pictureBox81
            // 
            this.pictureBox81.Location = new System.Drawing.Point(139, 159);
            this.pictureBox81.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox81.Name = "pictureBox81";
            this.pictureBox81.Size = new System.Drawing.Size(14, 15);
            this.pictureBox81.TabIndex = 167;
            this.pictureBox81.TabStop = false;
            // 
            // pictureBox82
            // 
            this.pictureBox82.Location = new System.Drawing.Point(139, 138);
            this.pictureBox82.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox82.Name = "pictureBox82";
            this.pictureBox82.Size = new System.Drawing.Size(14, 15);
            this.pictureBox82.TabIndex = 166;
            this.pictureBox82.TabStop = false;
            // 
            // pictureBox83
            // 
            this.pictureBox83.Location = new System.Drawing.Point(139, 116);
            this.pictureBox83.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox83.Name = "pictureBox83";
            this.pictureBox83.Size = new System.Drawing.Size(14, 15);
            this.pictureBox83.TabIndex = 165;
            this.pictureBox83.TabStop = false;
            // 
            // pictureBox84
            // 
            this.pictureBox84.Location = new System.Drawing.Point(139, 93);
            this.pictureBox84.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox84.Name = "pictureBox84";
            this.pictureBox84.Size = new System.Drawing.Size(14, 15);
            this.pictureBox84.TabIndex = 164;
            this.pictureBox84.TabStop = false;
            // 
            // pictureBox85
            // 
            this.pictureBox85.Location = new System.Drawing.Point(139, 74);
            this.pictureBox85.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox85.Name = "pictureBox85";
            this.pictureBox85.Size = new System.Drawing.Size(14, 15);
            this.pictureBox85.TabIndex = 163;
            this.pictureBox85.TabStop = false;
            // 
            // pictureBox86
            // 
            this.pictureBox86.Location = new System.Drawing.Point(139, 53);
            this.pictureBox86.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox86.Name = "pictureBox86";
            this.pictureBox86.Size = new System.Drawing.Size(14, 15);
            this.pictureBox86.TabIndex = 162;
            this.pictureBox86.TabStop = false;
            // 
            // pictureBox87
            // 
            this.pictureBox87.Location = new System.Drawing.Point(106, 158);
            this.pictureBox87.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox87.Name = "pictureBox87";
            this.pictureBox87.Size = new System.Drawing.Size(14, 15);
            this.pictureBox87.TabIndex = 161;
            this.pictureBox87.TabStop = false;
            // 
            // pictureBox88
            // 
            this.pictureBox88.Location = new System.Drawing.Point(106, 138);
            this.pictureBox88.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox88.Name = "pictureBox88";
            this.pictureBox88.Size = new System.Drawing.Size(14, 15);
            this.pictureBox88.TabIndex = 160;
            this.pictureBox88.TabStop = false;
            // 
            // pictureBox89
            // 
            this.pictureBox89.Location = new System.Drawing.Point(106, 116);
            this.pictureBox89.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox89.Name = "pictureBox89";
            this.pictureBox89.Size = new System.Drawing.Size(14, 15);
            this.pictureBox89.TabIndex = 159;
            this.pictureBox89.TabStop = false;
            // 
            // pictureBox90
            // 
            this.pictureBox90.Location = new System.Drawing.Point(106, 93);
            this.pictureBox90.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox90.Name = "pictureBox90";
            this.pictureBox90.Size = new System.Drawing.Size(14, 15);
            this.pictureBox90.TabIndex = 158;
            this.pictureBox90.TabStop = false;
            // 
            // pictureBox91
            // 
            this.pictureBox91.Location = new System.Drawing.Point(106, 74);
            this.pictureBox91.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox91.Name = "pictureBox91";
            this.pictureBox91.Size = new System.Drawing.Size(14, 15);
            this.pictureBox91.TabIndex = 157;
            this.pictureBox91.TabStop = false;
            // 
            // pictureBox92
            // 
            this.pictureBox92.Location = new System.Drawing.Point(106, 53);
            this.pictureBox92.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox92.Name = "pictureBox92";
            this.pictureBox92.Size = new System.Drawing.Size(14, 15);
            this.pictureBox92.TabIndex = 156;
            this.pictureBox92.TabStop = false;
            // 
            // pictureBox93
            // 
            this.pictureBox93.Location = new System.Drawing.Point(77, 159);
            this.pictureBox93.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox93.Name = "pictureBox93";
            this.pictureBox93.Size = new System.Drawing.Size(14, 15);
            this.pictureBox93.TabIndex = 155;
            this.pictureBox93.TabStop = false;
            // 
            // pictureBox94
            // 
            this.pictureBox94.Location = new System.Drawing.Point(77, 138);
            this.pictureBox94.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox94.Name = "pictureBox94";
            this.pictureBox94.Size = new System.Drawing.Size(14, 15);
            this.pictureBox94.TabIndex = 154;
            this.pictureBox94.TabStop = false;
            // 
            // pictureBox95
            // 
            this.pictureBox95.Location = new System.Drawing.Point(77, 116);
            this.pictureBox95.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox95.Name = "pictureBox95";
            this.pictureBox95.Size = new System.Drawing.Size(14, 15);
            this.pictureBox95.TabIndex = 153;
            this.pictureBox95.TabStop = false;
            // 
            // pictureBox96
            // 
            this.pictureBox96.Location = new System.Drawing.Point(77, 93);
            this.pictureBox96.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox96.Name = "pictureBox96";
            this.pictureBox96.Size = new System.Drawing.Size(14, 15);
            this.pictureBox96.TabIndex = 152;
            this.pictureBox96.TabStop = false;
            // 
            // pictureBox97
            // 
            this.pictureBox97.Location = new System.Drawing.Point(77, 74);
            this.pictureBox97.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox97.Name = "pictureBox97";
            this.pictureBox97.Size = new System.Drawing.Size(14, 15);
            this.pictureBox97.TabIndex = 151;
            this.pictureBox97.TabStop = false;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(13, 159);
            this.label20.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(64, 13);
            this.label20.TabIndex = 150;
            this.label20.Text = "18:00-20:00";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(13, 138);
            this.label21.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(64, 13);
            this.label21.TabIndex = 149;
            this.label21.Text = "16:00-18:00";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(13, 116);
            this.label22.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(64, 13);
            this.label22.TabIndex = 148;
            this.label22.Text = "14:00-16:00";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(13, 93);
            this.label23.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(64, 13);
            this.label23.TabIndex = 147;
            this.label23.Text = "12:00-14:00";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(13, 74);
            this.label24.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(64, 13);
            this.label24.TabIndex = 146;
            this.label24.Text = "10:00-12:00";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(18, 54);
            this.label25.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(58, 13);
            this.label25.TabIndex = 145;
            this.label25.Text = "8:00-10:00";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(244, 32);
            this.label26.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(26, 13);
            this.label26.TabIndex = 144;
            this.label26.Text = "Sun";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(220, 32);
            this.label27.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(23, 13);
            this.label27.TabIndex = 143;
            this.label27.Text = "Sat";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(199, 32);
            this.label28.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(18, 13);
            this.label28.TabIndex = 142;
            this.label28.Text = "Fri";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(164, 32);
            this.label29.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(34, 13);
            this.label29.TabIndex = 141;
            this.label29.Text = "Thurs";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(132, 32);
            this.label30.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(30, 13);
            this.label30.TabIndex = 140;
            this.label30.Text = "Wed";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(104, 32);
            this.label31.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(26, 13);
            this.label31.TabIndex = 139;
            this.label31.Text = "Tue";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(75, 32);
            this.label32.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(28, 13);
            this.label32.TabIndex = 138;
            this.label32.Text = "Mon";
            // 
            // pictureBox98
            // 
            this.pictureBox98.Location = new System.Drawing.Point(77, 53);
            this.pictureBox98.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox98.Name = "pictureBox98";
            this.pictureBox98.Size = new System.Drawing.Size(14, 15);
            this.pictureBox98.TabIndex = 137;
            this.pictureBox98.TabStop = false;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.pictureBox99);
            this.tabPage3.Controls.Add(this.pictureBox100);
            this.tabPage3.Controls.Add(this.pictureBox101);
            this.tabPage3.Controls.Add(this.pictureBox102);
            this.tabPage3.Controls.Add(this.pictureBox103);
            this.tabPage3.Controls.Add(this.pictureBox104);
            this.tabPage3.Controls.Add(this.pictureBox105);
            this.tabPage3.Controls.Add(this.label33);
            this.tabPage3.Controls.Add(this.pictureBox106);
            this.tabPage3.Controls.Add(this.pictureBox107);
            this.tabPage3.Controls.Add(this.pictureBox108);
            this.tabPage3.Controls.Add(this.pictureBox109);
            this.tabPage3.Controls.Add(this.pictureBox110);
            this.tabPage3.Controls.Add(this.pictureBox111);
            this.tabPage3.Controls.Add(this.pictureBox112);
            this.tabPage3.Controls.Add(this.pictureBox113);
            this.tabPage3.Controls.Add(this.pictureBox114);
            this.tabPage3.Controls.Add(this.pictureBox115);
            this.tabPage3.Controls.Add(this.pictureBox116);
            this.tabPage3.Controls.Add(this.pictureBox117);
            this.tabPage3.Controls.Add(this.pictureBox118);
            this.tabPage3.Controls.Add(this.pictureBox119);
            this.tabPage3.Controls.Add(this.pictureBox120);
            this.tabPage3.Controls.Add(this.pictureBox121);
            this.tabPage3.Controls.Add(this.pictureBox122);
            this.tabPage3.Controls.Add(this.pictureBox123);
            this.tabPage3.Controls.Add(this.pictureBox124);
            this.tabPage3.Controls.Add(this.pictureBox125);
            this.tabPage3.Controls.Add(this.pictureBox126);
            this.tabPage3.Controls.Add(this.pictureBox127);
            this.tabPage3.Controls.Add(this.pictureBox128);
            this.tabPage3.Controls.Add(this.pictureBox129);
            this.tabPage3.Controls.Add(this.pictureBox130);
            this.tabPage3.Controls.Add(this.pictureBox131);
            this.tabPage3.Controls.Add(this.pictureBox132);
            this.tabPage3.Controls.Add(this.pictureBox133);
            this.tabPage3.Controls.Add(this.pictureBox134);
            this.tabPage3.Controls.Add(this.pictureBox135);
            this.tabPage3.Controls.Add(this.pictureBox136);
            this.tabPage3.Controls.Add(this.pictureBox137);
            this.tabPage3.Controls.Add(this.pictureBox138);
            this.tabPage3.Controls.Add(this.pictureBox139);
            this.tabPage3.Controls.Add(this.pictureBox140);
            this.tabPage3.Controls.Add(this.pictureBox141);
            this.tabPage3.Controls.Add(this.pictureBox142);
            this.tabPage3.Controls.Add(this.pictureBox143);
            this.tabPage3.Controls.Add(this.pictureBox144);
            this.tabPage3.Controls.Add(this.pictureBox145);
            this.tabPage3.Controls.Add(this.pictureBox146);
            this.tabPage3.Controls.Add(this.label34);
            this.tabPage3.Controls.Add(this.label35);
            this.tabPage3.Controls.Add(this.label36);
            this.tabPage3.Controls.Add(this.label37);
            this.tabPage3.Controls.Add(this.label38);
            this.tabPage3.Controls.Add(this.label39);
            this.tabPage3.Controls.Add(this.label40);
            this.tabPage3.Controls.Add(this.label41);
            this.tabPage3.Controls.Add(this.label42);
            this.tabPage3.Controls.Add(this.label43);
            this.tabPage3.Controls.Add(this.label44);
            this.tabPage3.Controls.Add(this.label45);
            this.tabPage3.Controls.Add(this.label46);
            this.tabPage3.Controls.Add(this.pictureBox147);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(277, 228);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "3rd floor";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // pictureBox99
            // 
            this.pictureBox99.Location = new System.Drawing.Point(254, 177);
            this.pictureBox99.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox99.Name = "pictureBox99";
            this.pictureBox99.Size = new System.Drawing.Size(14, 15);
            this.pictureBox99.TabIndex = 136;
            this.pictureBox99.TabStop = false;
            // 
            // pictureBox100
            // 
            this.pictureBox100.Location = new System.Drawing.Point(226, 177);
            this.pictureBox100.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox100.Name = "pictureBox100";
            this.pictureBox100.Size = new System.Drawing.Size(14, 15);
            this.pictureBox100.TabIndex = 135;
            this.pictureBox100.TabStop = false;
            // 
            // pictureBox101
            // 
            this.pictureBox101.Location = new System.Drawing.Point(197, 179);
            this.pictureBox101.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox101.Name = "pictureBox101";
            this.pictureBox101.Size = new System.Drawing.Size(14, 15);
            this.pictureBox101.TabIndex = 134;
            this.pictureBox101.TabStop = false;
            // 
            // pictureBox102
            // 
            this.pictureBox102.Location = new System.Drawing.Point(168, 177);
            this.pictureBox102.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox102.Name = "pictureBox102";
            this.pictureBox102.Size = new System.Drawing.Size(14, 15);
            this.pictureBox102.TabIndex = 133;
            this.pictureBox102.TabStop = false;
            // 
            // pictureBox103
            // 
            this.pictureBox103.Location = new System.Drawing.Point(139, 179);
            this.pictureBox103.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox103.Name = "pictureBox103";
            this.pictureBox103.Size = new System.Drawing.Size(14, 15);
            this.pictureBox103.TabIndex = 132;
            this.pictureBox103.TabStop = false;
            // 
            // pictureBox104
            // 
            this.pictureBox104.Location = new System.Drawing.Point(106, 177);
            this.pictureBox104.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox104.Name = "pictureBox104";
            this.pictureBox104.Size = new System.Drawing.Size(14, 15);
            this.pictureBox104.TabIndex = 131;
            this.pictureBox104.TabStop = false;
            // 
            // pictureBox105
            // 
            this.pictureBox105.Location = new System.Drawing.Point(77, 179);
            this.pictureBox105.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox105.Name = "pictureBox105";
            this.pictureBox105.Size = new System.Drawing.Size(14, 15);
            this.pictureBox105.TabIndex = 130;
            this.pictureBox105.TabStop = false;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(13, 184);
            this.label33.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(64, 13);
            this.label33.TabIndex = 129;
            this.label33.Text = "20:00-22:00";
            // 
            // pictureBox106
            // 
            this.pictureBox106.Location = new System.Drawing.Point(254, 158);
            this.pictureBox106.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox106.Name = "pictureBox106";
            this.pictureBox106.Size = new System.Drawing.Size(14, 15);
            this.pictureBox106.TabIndex = 128;
            this.pictureBox106.TabStop = false;
            // 
            // pictureBox107
            // 
            this.pictureBox107.Location = new System.Drawing.Point(254, 138);
            this.pictureBox107.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox107.Name = "pictureBox107";
            this.pictureBox107.Size = new System.Drawing.Size(14, 15);
            this.pictureBox107.TabIndex = 127;
            this.pictureBox107.TabStop = false;
            // 
            // pictureBox108
            // 
            this.pictureBox108.Location = new System.Drawing.Point(254, 116);
            this.pictureBox108.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox108.Name = "pictureBox108";
            this.pictureBox108.Size = new System.Drawing.Size(14, 15);
            this.pictureBox108.TabIndex = 126;
            this.pictureBox108.TabStop = false;
            // 
            // pictureBox109
            // 
            this.pictureBox109.Location = new System.Drawing.Point(254, 93);
            this.pictureBox109.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox109.Name = "pictureBox109";
            this.pictureBox109.Size = new System.Drawing.Size(14, 15);
            this.pictureBox109.TabIndex = 125;
            this.pictureBox109.TabStop = false;
            // 
            // pictureBox110
            // 
            this.pictureBox110.Location = new System.Drawing.Point(254, 74);
            this.pictureBox110.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox110.Name = "pictureBox110";
            this.pictureBox110.Size = new System.Drawing.Size(14, 15);
            this.pictureBox110.TabIndex = 124;
            this.pictureBox110.TabStop = false;
            // 
            // pictureBox111
            // 
            this.pictureBox111.Location = new System.Drawing.Point(254, 53);
            this.pictureBox111.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox111.Name = "pictureBox111";
            this.pictureBox111.Size = new System.Drawing.Size(14, 15);
            this.pictureBox111.TabIndex = 123;
            this.pictureBox111.TabStop = false;
            // 
            // pictureBox112
            // 
            this.pictureBox112.Location = new System.Drawing.Point(226, 158);
            this.pictureBox112.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox112.Name = "pictureBox112";
            this.pictureBox112.Size = new System.Drawing.Size(14, 15);
            this.pictureBox112.TabIndex = 122;
            this.pictureBox112.TabStop = false;
            // 
            // pictureBox113
            // 
            this.pictureBox113.Location = new System.Drawing.Point(226, 138);
            this.pictureBox113.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox113.Name = "pictureBox113";
            this.pictureBox113.Size = new System.Drawing.Size(14, 15);
            this.pictureBox113.TabIndex = 121;
            this.pictureBox113.TabStop = false;
            // 
            // pictureBox114
            // 
            this.pictureBox114.Location = new System.Drawing.Point(226, 116);
            this.pictureBox114.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox114.Name = "pictureBox114";
            this.pictureBox114.Size = new System.Drawing.Size(14, 15);
            this.pictureBox114.TabIndex = 120;
            this.pictureBox114.TabStop = false;
            // 
            // pictureBox115
            // 
            this.pictureBox115.Location = new System.Drawing.Point(226, 93);
            this.pictureBox115.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox115.Name = "pictureBox115";
            this.pictureBox115.Size = new System.Drawing.Size(14, 15);
            this.pictureBox115.TabIndex = 119;
            this.pictureBox115.TabStop = false;
            // 
            // pictureBox116
            // 
            this.pictureBox116.Location = new System.Drawing.Point(226, 74);
            this.pictureBox116.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox116.Name = "pictureBox116";
            this.pictureBox116.Size = new System.Drawing.Size(14, 15);
            this.pictureBox116.TabIndex = 118;
            this.pictureBox116.TabStop = false;
            // 
            // pictureBox117
            // 
            this.pictureBox117.Location = new System.Drawing.Point(226, 53);
            this.pictureBox117.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox117.Name = "pictureBox117";
            this.pictureBox117.Size = new System.Drawing.Size(14, 15);
            this.pictureBox117.TabIndex = 117;
            this.pictureBox117.TabStop = false;
            // 
            // pictureBox118
            // 
            this.pictureBox118.Location = new System.Drawing.Point(197, 159);
            this.pictureBox118.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox118.Name = "pictureBox118";
            this.pictureBox118.Size = new System.Drawing.Size(14, 15);
            this.pictureBox118.TabIndex = 116;
            this.pictureBox118.TabStop = false;
            // 
            // pictureBox119
            // 
            this.pictureBox119.Location = new System.Drawing.Point(197, 138);
            this.pictureBox119.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox119.Name = "pictureBox119";
            this.pictureBox119.Size = new System.Drawing.Size(14, 15);
            this.pictureBox119.TabIndex = 115;
            this.pictureBox119.TabStop = false;
            // 
            // pictureBox120
            // 
            this.pictureBox120.Location = new System.Drawing.Point(197, 116);
            this.pictureBox120.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox120.Name = "pictureBox120";
            this.pictureBox120.Size = new System.Drawing.Size(14, 15);
            this.pictureBox120.TabIndex = 114;
            this.pictureBox120.TabStop = false;
            // 
            // pictureBox121
            // 
            this.pictureBox121.Location = new System.Drawing.Point(197, 93);
            this.pictureBox121.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox121.Name = "pictureBox121";
            this.pictureBox121.Size = new System.Drawing.Size(14, 15);
            this.pictureBox121.TabIndex = 113;
            this.pictureBox121.TabStop = false;
            // 
            // pictureBox122
            // 
            this.pictureBox122.Location = new System.Drawing.Point(197, 74);
            this.pictureBox122.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox122.Name = "pictureBox122";
            this.pictureBox122.Size = new System.Drawing.Size(14, 15);
            this.pictureBox122.TabIndex = 112;
            this.pictureBox122.TabStop = false;
            // 
            // pictureBox123
            // 
            this.pictureBox123.Location = new System.Drawing.Point(197, 53);
            this.pictureBox123.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox123.Name = "pictureBox123";
            this.pictureBox123.Size = new System.Drawing.Size(14, 15);
            this.pictureBox123.TabIndex = 111;
            this.pictureBox123.TabStop = false;
            // 
            // pictureBox124
            // 
            this.pictureBox124.Location = new System.Drawing.Point(168, 158);
            this.pictureBox124.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox124.Name = "pictureBox124";
            this.pictureBox124.Size = new System.Drawing.Size(14, 15);
            this.pictureBox124.TabIndex = 110;
            this.pictureBox124.TabStop = false;
            // 
            // pictureBox125
            // 
            this.pictureBox125.Location = new System.Drawing.Point(168, 138);
            this.pictureBox125.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox125.Name = "pictureBox125";
            this.pictureBox125.Size = new System.Drawing.Size(14, 15);
            this.pictureBox125.TabIndex = 109;
            this.pictureBox125.TabStop = false;
            // 
            // pictureBox126
            // 
            this.pictureBox126.Location = new System.Drawing.Point(168, 116);
            this.pictureBox126.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox126.Name = "pictureBox126";
            this.pictureBox126.Size = new System.Drawing.Size(14, 15);
            this.pictureBox126.TabIndex = 108;
            this.pictureBox126.TabStop = false;
            // 
            // pictureBox127
            // 
            this.pictureBox127.Location = new System.Drawing.Point(168, 93);
            this.pictureBox127.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox127.Name = "pictureBox127";
            this.pictureBox127.Size = new System.Drawing.Size(14, 15);
            this.pictureBox127.TabIndex = 107;
            this.pictureBox127.TabStop = false;
            // 
            // pictureBox128
            // 
            this.pictureBox128.Location = new System.Drawing.Point(168, 74);
            this.pictureBox128.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox128.Name = "pictureBox128";
            this.pictureBox128.Size = new System.Drawing.Size(14, 15);
            this.pictureBox128.TabIndex = 106;
            this.pictureBox128.TabStop = false;
            // 
            // pictureBox129
            // 
            this.pictureBox129.Location = new System.Drawing.Point(168, 53);
            this.pictureBox129.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox129.Name = "pictureBox129";
            this.pictureBox129.Size = new System.Drawing.Size(14, 15);
            this.pictureBox129.TabIndex = 105;
            this.pictureBox129.TabStop = false;
            // 
            // pictureBox130
            // 
            this.pictureBox130.Location = new System.Drawing.Point(139, 159);
            this.pictureBox130.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox130.Name = "pictureBox130";
            this.pictureBox130.Size = new System.Drawing.Size(14, 15);
            this.pictureBox130.TabIndex = 104;
            this.pictureBox130.TabStop = false;
            // 
            // pictureBox131
            // 
            this.pictureBox131.Location = new System.Drawing.Point(139, 138);
            this.pictureBox131.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox131.Name = "pictureBox131";
            this.pictureBox131.Size = new System.Drawing.Size(14, 15);
            this.pictureBox131.TabIndex = 103;
            this.pictureBox131.TabStop = false;
            // 
            // pictureBox132
            // 
            this.pictureBox132.Location = new System.Drawing.Point(139, 116);
            this.pictureBox132.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox132.Name = "pictureBox132";
            this.pictureBox132.Size = new System.Drawing.Size(14, 15);
            this.pictureBox132.TabIndex = 102;
            this.pictureBox132.TabStop = false;
            // 
            // pictureBox133
            // 
            this.pictureBox133.Location = new System.Drawing.Point(139, 93);
            this.pictureBox133.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox133.Name = "pictureBox133";
            this.pictureBox133.Size = new System.Drawing.Size(14, 15);
            this.pictureBox133.TabIndex = 101;
            this.pictureBox133.TabStop = false;
            // 
            // pictureBox134
            // 
            this.pictureBox134.Location = new System.Drawing.Point(139, 74);
            this.pictureBox134.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox134.Name = "pictureBox134";
            this.pictureBox134.Size = new System.Drawing.Size(14, 15);
            this.pictureBox134.TabIndex = 100;
            this.pictureBox134.TabStop = false;
            // 
            // pictureBox135
            // 
            this.pictureBox135.Location = new System.Drawing.Point(139, 53);
            this.pictureBox135.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox135.Name = "pictureBox135";
            this.pictureBox135.Size = new System.Drawing.Size(14, 15);
            this.pictureBox135.TabIndex = 99;
            this.pictureBox135.TabStop = false;
            // 
            // pictureBox136
            // 
            this.pictureBox136.Location = new System.Drawing.Point(106, 158);
            this.pictureBox136.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox136.Name = "pictureBox136";
            this.pictureBox136.Size = new System.Drawing.Size(14, 15);
            this.pictureBox136.TabIndex = 98;
            this.pictureBox136.TabStop = false;
            // 
            // pictureBox137
            // 
            this.pictureBox137.Location = new System.Drawing.Point(106, 138);
            this.pictureBox137.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox137.Name = "pictureBox137";
            this.pictureBox137.Size = new System.Drawing.Size(14, 15);
            this.pictureBox137.TabIndex = 97;
            this.pictureBox137.TabStop = false;
            // 
            // pictureBox138
            // 
            this.pictureBox138.Location = new System.Drawing.Point(106, 116);
            this.pictureBox138.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox138.Name = "pictureBox138";
            this.pictureBox138.Size = new System.Drawing.Size(14, 15);
            this.pictureBox138.TabIndex = 96;
            this.pictureBox138.TabStop = false;
            // 
            // pictureBox139
            // 
            this.pictureBox139.Location = new System.Drawing.Point(106, 93);
            this.pictureBox139.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox139.Name = "pictureBox139";
            this.pictureBox139.Size = new System.Drawing.Size(14, 15);
            this.pictureBox139.TabIndex = 95;
            this.pictureBox139.TabStop = false;
            // 
            // pictureBox140
            // 
            this.pictureBox140.Location = new System.Drawing.Point(106, 74);
            this.pictureBox140.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox140.Name = "pictureBox140";
            this.pictureBox140.Size = new System.Drawing.Size(14, 15);
            this.pictureBox140.TabIndex = 94;
            this.pictureBox140.TabStop = false;
            // 
            // pictureBox141
            // 
            this.pictureBox141.Location = new System.Drawing.Point(106, 53);
            this.pictureBox141.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox141.Name = "pictureBox141";
            this.pictureBox141.Size = new System.Drawing.Size(14, 15);
            this.pictureBox141.TabIndex = 93;
            this.pictureBox141.TabStop = false;
            // 
            // pictureBox142
            // 
            this.pictureBox142.Location = new System.Drawing.Point(77, 159);
            this.pictureBox142.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox142.Name = "pictureBox142";
            this.pictureBox142.Size = new System.Drawing.Size(14, 15);
            this.pictureBox142.TabIndex = 92;
            this.pictureBox142.TabStop = false;
            // 
            // pictureBox143
            // 
            this.pictureBox143.Location = new System.Drawing.Point(77, 138);
            this.pictureBox143.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox143.Name = "pictureBox143";
            this.pictureBox143.Size = new System.Drawing.Size(14, 15);
            this.pictureBox143.TabIndex = 91;
            this.pictureBox143.TabStop = false;
            // 
            // pictureBox144
            // 
            this.pictureBox144.Location = new System.Drawing.Point(77, 116);
            this.pictureBox144.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox144.Name = "pictureBox144";
            this.pictureBox144.Size = new System.Drawing.Size(14, 15);
            this.pictureBox144.TabIndex = 90;
            this.pictureBox144.TabStop = false;
            // 
            // pictureBox145
            // 
            this.pictureBox145.Location = new System.Drawing.Point(77, 93);
            this.pictureBox145.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox145.Name = "pictureBox145";
            this.pictureBox145.Size = new System.Drawing.Size(14, 15);
            this.pictureBox145.TabIndex = 89;
            this.pictureBox145.TabStop = false;
            // 
            // pictureBox146
            // 
            this.pictureBox146.Location = new System.Drawing.Point(77, 74);
            this.pictureBox146.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox146.Name = "pictureBox146";
            this.pictureBox146.Size = new System.Drawing.Size(14, 15);
            this.pictureBox146.TabIndex = 88;
            this.pictureBox146.TabStop = false;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(13, 159);
            this.label34.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(64, 13);
            this.label34.TabIndex = 87;
            this.label34.Text = "18:00-20:00";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(13, 138);
            this.label35.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(64, 13);
            this.label35.TabIndex = 86;
            this.label35.Text = "16:00-18:00";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(13, 116);
            this.label36.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(64, 13);
            this.label36.TabIndex = 85;
            this.label36.Text = "14:00-16:00";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(13, 93);
            this.label37.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(64, 13);
            this.label37.TabIndex = 84;
            this.label37.Text = "12:00-14:00";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(13, 74);
            this.label38.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(64, 13);
            this.label38.TabIndex = 83;
            this.label38.Text = "10:00-12:00";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(18, 54);
            this.label39.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(58, 13);
            this.label39.TabIndex = 82;
            this.label39.Text = "8:00-10:00";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(244, 32);
            this.label40.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(26, 13);
            this.label40.TabIndex = 81;
            this.label40.Text = "Sun";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(220, 32);
            this.label41.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(23, 13);
            this.label41.TabIndex = 80;
            this.label41.Text = "Sat";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(199, 32);
            this.label42.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(18, 13);
            this.label42.TabIndex = 79;
            this.label42.Text = "Fri";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(164, 32);
            this.label43.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(34, 13);
            this.label43.TabIndex = 78;
            this.label43.Text = "Thurs";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(132, 32);
            this.label44.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(30, 13);
            this.label44.TabIndex = 77;
            this.label44.Text = "Wed";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(104, 32);
            this.label45.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(26, 13);
            this.label45.TabIndex = 76;
            this.label45.Text = "Tue";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(75, 32);
            this.label46.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(28, 13);
            this.label46.TabIndex = 75;
            this.label46.Text = "Mon";
            // 
            // pictureBox147
            // 
            this.pictureBox147.Location = new System.Drawing.Point(77, 53);
            this.pictureBox147.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox147.Name = "pictureBox147";
            this.pictureBox147.Size = new System.Drawing.Size(14, 15);
            this.pictureBox147.TabIndex = 74;
            this.pictureBox147.TabStop = false;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.pictureBox148);
            this.tabPage4.Controls.Add(this.pictureBox149);
            this.tabPage4.Controls.Add(this.pictureBox150);
            this.tabPage4.Controls.Add(this.pictureBox151);
            this.tabPage4.Controls.Add(this.pictureBox152);
            this.tabPage4.Controls.Add(this.pictureBox153);
            this.tabPage4.Controls.Add(this.pictureBox154);
            this.tabPage4.Controls.Add(this.label47);
            this.tabPage4.Controls.Add(this.pictureBox155);
            this.tabPage4.Controls.Add(this.pictureBox156);
            this.tabPage4.Controls.Add(this.pictureBox157);
            this.tabPage4.Controls.Add(this.pictureBox158);
            this.tabPage4.Controls.Add(this.pictureBox159);
            this.tabPage4.Controls.Add(this.pictureBox160);
            this.tabPage4.Controls.Add(this.pictureBox161);
            this.tabPage4.Controls.Add(this.pictureBox162);
            this.tabPage4.Controls.Add(this.pictureBox163);
            this.tabPage4.Controls.Add(this.pictureBox164);
            this.tabPage4.Controls.Add(this.pictureBox165);
            this.tabPage4.Controls.Add(this.pictureBox166);
            this.tabPage4.Controls.Add(this.pictureBox167);
            this.tabPage4.Controls.Add(this.pictureBox168);
            this.tabPage4.Controls.Add(this.pictureBox169);
            this.tabPage4.Controls.Add(this.pictureBox170);
            this.tabPage4.Controls.Add(this.pictureBox171);
            this.tabPage4.Controls.Add(this.pictureBox172);
            this.tabPage4.Controls.Add(this.pictureBox173);
            this.tabPage4.Controls.Add(this.pictureBox174);
            this.tabPage4.Controls.Add(this.pictureBox175);
            this.tabPage4.Controls.Add(this.pictureBox176);
            this.tabPage4.Controls.Add(this.pictureBox177);
            this.tabPage4.Controls.Add(this.pictureBox178);
            this.tabPage4.Controls.Add(this.pictureBox179);
            this.tabPage4.Controls.Add(this.pictureBox180);
            this.tabPage4.Controls.Add(this.pictureBox181);
            this.tabPage4.Controls.Add(this.pictureBox182);
            this.tabPage4.Controls.Add(this.pictureBox183);
            this.tabPage4.Controls.Add(this.pictureBox184);
            this.tabPage4.Controls.Add(this.pictureBox185);
            this.tabPage4.Controls.Add(this.pictureBox186);
            this.tabPage4.Controls.Add(this.pictureBox187);
            this.tabPage4.Controls.Add(this.pictureBox188);
            this.tabPage4.Controls.Add(this.pictureBox189);
            this.tabPage4.Controls.Add(this.pictureBox190);
            this.tabPage4.Controls.Add(this.pictureBox191);
            this.tabPage4.Controls.Add(this.pictureBox192);
            this.tabPage4.Controls.Add(this.pictureBox193);
            this.tabPage4.Controls.Add(this.pictureBox194);
            this.tabPage4.Controls.Add(this.pictureBox195);
            this.tabPage4.Controls.Add(this.label48);
            this.tabPage4.Controls.Add(this.label49);
            this.tabPage4.Controls.Add(this.label50);
            this.tabPage4.Controls.Add(this.label51);
            this.tabPage4.Controls.Add(this.label52);
            this.tabPage4.Controls.Add(this.label53);
            this.tabPage4.Controls.Add(this.label54);
            this.tabPage4.Controls.Add(this.label55);
            this.tabPage4.Controls.Add(this.label56);
            this.tabPage4.Controls.Add(this.label57);
            this.tabPage4.Controls.Add(this.label58);
            this.tabPage4.Controls.Add(this.label59);
            this.tabPage4.Controls.Add(this.label60);
            this.tabPage4.Controls.Add(this.pictureBox196);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(277, 228);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "4th floor";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // pictureBox148
            // 
            this.pictureBox148.Location = new System.Drawing.Point(254, 177);
            this.pictureBox148.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox148.Name = "pictureBox148";
            this.pictureBox148.Size = new System.Drawing.Size(14, 15);
            this.pictureBox148.TabIndex = 136;
            this.pictureBox148.TabStop = false;
            // 
            // pictureBox149
            // 
            this.pictureBox149.Location = new System.Drawing.Point(226, 177);
            this.pictureBox149.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox149.Name = "pictureBox149";
            this.pictureBox149.Size = new System.Drawing.Size(14, 15);
            this.pictureBox149.TabIndex = 135;
            this.pictureBox149.TabStop = false;
            // 
            // pictureBox150
            // 
            this.pictureBox150.Location = new System.Drawing.Point(197, 179);
            this.pictureBox150.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox150.Name = "pictureBox150";
            this.pictureBox150.Size = new System.Drawing.Size(14, 15);
            this.pictureBox150.TabIndex = 134;
            this.pictureBox150.TabStop = false;
            // 
            // pictureBox151
            // 
            this.pictureBox151.Location = new System.Drawing.Point(168, 177);
            this.pictureBox151.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox151.Name = "pictureBox151";
            this.pictureBox151.Size = new System.Drawing.Size(14, 15);
            this.pictureBox151.TabIndex = 133;
            this.pictureBox151.TabStop = false;
            // 
            // pictureBox152
            // 
            this.pictureBox152.Location = new System.Drawing.Point(139, 179);
            this.pictureBox152.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox152.Name = "pictureBox152";
            this.pictureBox152.Size = new System.Drawing.Size(14, 15);
            this.pictureBox152.TabIndex = 132;
            this.pictureBox152.TabStop = false;
            // 
            // pictureBox153
            // 
            this.pictureBox153.Location = new System.Drawing.Point(106, 177);
            this.pictureBox153.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox153.Name = "pictureBox153";
            this.pictureBox153.Size = new System.Drawing.Size(14, 15);
            this.pictureBox153.TabIndex = 131;
            this.pictureBox153.TabStop = false;
            // 
            // pictureBox154
            // 
            this.pictureBox154.Location = new System.Drawing.Point(77, 179);
            this.pictureBox154.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox154.Name = "pictureBox154";
            this.pictureBox154.Size = new System.Drawing.Size(14, 15);
            this.pictureBox154.TabIndex = 130;
            this.pictureBox154.TabStop = false;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(13, 184);
            this.label47.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(64, 13);
            this.label47.TabIndex = 129;
            this.label47.Text = "20:00-22:00";
            // 
            // pictureBox155
            // 
            this.pictureBox155.Location = new System.Drawing.Point(254, 158);
            this.pictureBox155.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox155.Name = "pictureBox155";
            this.pictureBox155.Size = new System.Drawing.Size(14, 15);
            this.pictureBox155.TabIndex = 128;
            this.pictureBox155.TabStop = false;
            // 
            // pictureBox156
            // 
            this.pictureBox156.Location = new System.Drawing.Point(254, 138);
            this.pictureBox156.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox156.Name = "pictureBox156";
            this.pictureBox156.Size = new System.Drawing.Size(14, 15);
            this.pictureBox156.TabIndex = 127;
            this.pictureBox156.TabStop = false;
            // 
            // pictureBox157
            // 
            this.pictureBox157.Location = new System.Drawing.Point(254, 116);
            this.pictureBox157.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox157.Name = "pictureBox157";
            this.pictureBox157.Size = new System.Drawing.Size(14, 15);
            this.pictureBox157.TabIndex = 126;
            this.pictureBox157.TabStop = false;
            // 
            // pictureBox158
            // 
            this.pictureBox158.Location = new System.Drawing.Point(254, 93);
            this.pictureBox158.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox158.Name = "pictureBox158";
            this.pictureBox158.Size = new System.Drawing.Size(14, 15);
            this.pictureBox158.TabIndex = 125;
            this.pictureBox158.TabStop = false;
            // 
            // pictureBox159
            // 
            this.pictureBox159.Location = new System.Drawing.Point(254, 74);
            this.pictureBox159.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox159.Name = "pictureBox159";
            this.pictureBox159.Size = new System.Drawing.Size(14, 15);
            this.pictureBox159.TabIndex = 124;
            this.pictureBox159.TabStop = false;
            // 
            // pictureBox160
            // 
            this.pictureBox160.Location = new System.Drawing.Point(254, 53);
            this.pictureBox160.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox160.Name = "pictureBox160";
            this.pictureBox160.Size = new System.Drawing.Size(14, 15);
            this.pictureBox160.TabIndex = 123;
            this.pictureBox160.TabStop = false;
            // 
            // pictureBox161
            // 
            this.pictureBox161.Location = new System.Drawing.Point(226, 158);
            this.pictureBox161.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox161.Name = "pictureBox161";
            this.pictureBox161.Size = new System.Drawing.Size(14, 15);
            this.pictureBox161.TabIndex = 122;
            this.pictureBox161.TabStop = false;
            // 
            // pictureBox162
            // 
            this.pictureBox162.Location = new System.Drawing.Point(226, 138);
            this.pictureBox162.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox162.Name = "pictureBox162";
            this.pictureBox162.Size = new System.Drawing.Size(14, 15);
            this.pictureBox162.TabIndex = 121;
            this.pictureBox162.TabStop = false;
            // 
            // pictureBox163
            // 
            this.pictureBox163.Location = new System.Drawing.Point(226, 116);
            this.pictureBox163.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox163.Name = "pictureBox163";
            this.pictureBox163.Size = new System.Drawing.Size(14, 15);
            this.pictureBox163.TabIndex = 120;
            this.pictureBox163.TabStop = false;
            // 
            // pictureBox164
            // 
            this.pictureBox164.Location = new System.Drawing.Point(226, 93);
            this.pictureBox164.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox164.Name = "pictureBox164";
            this.pictureBox164.Size = new System.Drawing.Size(14, 15);
            this.pictureBox164.TabIndex = 119;
            this.pictureBox164.TabStop = false;
            // 
            // pictureBox165
            // 
            this.pictureBox165.Location = new System.Drawing.Point(226, 74);
            this.pictureBox165.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox165.Name = "pictureBox165";
            this.pictureBox165.Size = new System.Drawing.Size(14, 15);
            this.pictureBox165.TabIndex = 118;
            this.pictureBox165.TabStop = false;
            // 
            // pictureBox166
            // 
            this.pictureBox166.Location = new System.Drawing.Point(226, 53);
            this.pictureBox166.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox166.Name = "pictureBox166";
            this.pictureBox166.Size = new System.Drawing.Size(14, 15);
            this.pictureBox166.TabIndex = 117;
            this.pictureBox166.TabStop = false;
            // 
            // pictureBox167
            // 
            this.pictureBox167.Location = new System.Drawing.Point(197, 159);
            this.pictureBox167.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox167.Name = "pictureBox167";
            this.pictureBox167.Size = new System.Drawing.Size(14, 15);
            this.pictureBox167.TabIndex = 116;
            this.pictureBox167.TabStop = false;
            // 
            // pictureBox168
            // 
            this.pictureBox168.Location = new System.Drawing.Point(197, 138);
            this.pictureBox168.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox168.Name = "pictureBox168";
            this.pictureBox168.Size = new System.Drawing.Size(14, 15);
            this.pictureBox168.TabIndex = 115;
            this.pictureBox168.TabStop = false;
            // 
            // pictureBox169
            // 
            this.pictureBox169.Location = new System.Drawing.Point(197, 116);
            this.pictureBox169.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox169.Name = "pictureBox169";
            this.pictureBox169.Size = new System.Drawing.Size(14, 15);
            this.pictureBox169.TabIndex = 114;
            this.pictureBox169.TabStop = false;
            // 
            // pictureBox170
            // 
            this.pictureBox170.Location = new System.Drawing.Point(197, 93);
            this.pictureBox170.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox170.Name = "pictureBox170";
            this.pictureBox170.Size = new System.Drawing.Size(14, 15);
            this.pictureBox170.TabIndex = 113;
            this.pictureBox170.TabStop = false;
            // 
            // pictureBox171
            // 
            this.pictureBox171.Location = new System.Drawing.Point(197, 74);
            this.pictureBox171.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox171.Name = "pictureBox171";
            this.pictureBox171.Size = new System.Drawing.Size(14, 15);
            this.pictureBox171.TabIndex = 112;
            this.pictureBox171.TabStop = false;
            // 
            // pictureBox172
            // 
            this.pictureBox172.Location = new System.Drawing.Point(197, 53);
            this.pictureBox172.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox172.Name = "pictureBox172";
            this.pictureBox172.Size = new System.Drawing.Size(14, 15);
            this.pictureBox172.TabIndex = 111;
            this.pictureBox172.TabStop = false;
            // 
            // pictureBox173
            // 
            this.pictureBox173.Location = new System.Drawing.Point(168, 158);
            this.pictureBox173.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox173.Name = "pictureBox173";
            this.pictureBox173.Size = new System.Drawing.Size(14, 15);
            this.pictureBox173.TabIndex = 110;
            this.pictureBox173.TabStop = false;
            // 
            // pictureBox174
            // 
            this.pictureBox174.Location = new System.Drawing.Point(168, 138);
            this.pictureBox174.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox174.Name = "pictureBox174";
            this.pictureBox174.Size = new System.Drawing.Size(14, 15);
            this.pictureBox174.TabIndex = 109;
            this.pictureBox174.TabStop = false;
            // 
            // pictureBox175
            // 
            this.pictureBox175.Location = new System.Drawing.Point(168, 116);
            this.pictureBox175.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox175.Name = "pictureBox175";
            this.pictureBox175.Size = new System.Drawing.Size(14, 15);
            this.pictureBox175.TabIndex = 108;
            this.pictureBox175.TabStop = false;
            // 
            // pictureBox176
            // 
            this.pictureBox176.Location = new System.Drawing.Point(168, 93);
            this.pictureBox176.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox176.Name = "pictureBox176";
            this.pictureBox176.Size = new System.Drawing.Size(14, 15);
            this.pictureBox176.TabIndex = 107;
            this.pictureBox176.TabStop = false;
            // 
            // pictureBox177
            // 
            this.pictureBox177.Location = new System.Drawing.Point(168, 74);
            this.pictureBox177.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox177.Name = "pictureBox177";
            this.pictureBox177.Size = new System.Drawing.Size(14, 15);
            this.pictureBox177.TabIndex = 106;
            this.pictureBox177.TabStop = false;
            // 
            // pictureBox178
            // 
            this.pictureBox178.Location = new System.Drawing.Point(168, 53);
            this.pictureBox178.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox178.Name = "pictureBox178";
            this.pictureBox178.Size = new System.Drawing.Size(14, 15);
            this.pictureBox178.TabIndex = 105;
            this.pictureBox178.TabStop = false;
            // 
            // pictureBox179
            // 
            this.pictureBox179.Location = new System.Drawing.Point(139, 159);
            this.pictureBox179.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox179.Name = "pictureBox179";
            this.pictureBox179.Size = new System.Drawing.Size(14, 15);
            this.pictureBox179.TabIndex = 104;
            this.pictureBox179.TabStop = false;
            // 
            // pictureBox180
            // 
            this.pictureBox180.Location = new System.Drawing.Point(139, 138);
            this.pictureBox180.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox180.Name = "pictureBox180";
            this.pictureBox180.Size = new System.Drawing.Size(14, 15);
            this.pictureBox180.TabIndex = 103;
            this.pictureBox180.TabStop = false;
            // 
            // pictureBox181
            // 
            this.pictureBox181.Location = new System.Drawing.Point(139, 116);
            this.pictureBox181.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox181.Name = "pictureBox181";
            this.pictureBox181.Size = new System.Drawing.Size(14, 15);
            this.pictureBox181.TabIndex = 102;
            this.pictureBox181.TabStop = false;
            // 
            // pictureBox182
            // 
            this.pictureBox182.Location = new System.Drawing.Point(139, 93);
            this.pictureBox182.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox182.Name = "pictureBox182";
            this.pictureBox182.Size = new System.Drawing.Size(14, 15);
            this.pictureBox182.TabIndex = 101;
            this.pictureBox182.TabStop = false;
            // 
            // pictureBox183
            // 
            this.pictureBox183.Location = new System.Drawing.Point(139, 74);
            this.pictureBox183.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox183.Name = "pictureBox183";
            this.pictureBox183.Size = new System.Drawing.Size(14, 15);
            this.pictureBox183.TabIndex = 100;
            this.pictureBox183.TabStop = false;
            // 
            // pictureBox184
            // 
            this.pictureBox184.Location = new System.Drawing.Point(139, 53);
            this.pictureBox184.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox184.Name = "pictureBox184";
            this.pictureBox184.Size = new System.Drawing.Size(14, 15);
            this.pictureBox184.TabIndex = 99;
            this.pictureBox184.TabStop = false;
            // 
            // pictureBox185
            // 
            this.pictureBox185.Location = new System.Drawing.Point(106, 158);
            this.pictureBox185.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox185.Name = "pictureBox185";
            this.pictureBox185.Size = new System.Drawing.Size(14, 15);
            this.pictureBox185.TabIndex = 98;
            this.pictureBox185.TabStop = false;
            // 
            // pictureBox186
            // 
            this.pictureBox186.Location = new System.Drawing.Point(106, 138);
            this.pictureBox186.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox186.Name = "pictureBox186";
            this.pictureBox186.Size = new System.Drawing.Size(14, 15);
            this.pictureBox186.TabIndex = 97;
            this.pictureBox186.TabStop = false;
            // 
            // pictureBox187
            // 
            this.pictureBox187.Location = new System.Drawing.Point(106, 116);
            this.pictureBox187.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox187.Name = "pictureBox187";
            this.pictureBox187.Size = new System.Drawing.Size(14, 15);
            this.pictureBox187.TabIndex = 96;
            this.pictureBox187.TabStop = false;
            // 
            // pictureBox188
            // 
            this.pictureBox188.Location = new System.Drawing.Point(106, 93);
            this.pictureBox188.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox188.Name = "pictureBox188";
            this.pictureBox188.Size = new System.Drawing.Size(14, 15);
            this.pictureBox188.TabIndex = 95;
            this.pictureBox188.TabStop = false;
            // 
            // pictureBox189
            // 
            this.pictureBox189.Location = new System.Drawing.Point(106, 74);
            this.pictureBox189.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox189.Name = "pictureBox189";
            this.pictureBox189.Size = new System.Drawing.Size(14, 15);
            this.pictureBox189.TabIndex = 94;
            this.pictureBox189.TabStop = false;
            // 
            // pictureBox190
            // 
            this.pictureBox190.Location = new System.Drawing.Point(106, 53);
            this.pictureBox190.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox190.Name = "pictureBox190";
            this.pictureBox190.Size = new System.Drawing.Size(14, 15);
            this.pictureBox190.TabIndex = 93;
            this.pictureBox190.TabStop = false;
            // 
            // pictureBox191
            // 
            this.pictureBox191.Location = new System.Drawing.Point(77, 159);
            this.pictureBox191.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox191.Name = "pictureBox191";
            this.pictureBox191.Size = new System.Drawing.Size(14, 15);
            this.pictureBox191.TabIndex = 92;
            this.pictureBox191.TabStop = false;
            // 
            // pictureBox192
            // 
            this.pictureBox192.Location = new System.Drawing.Point(77, 138);
            this.pictureBox192.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox192.Name = "pictureBox192";
            this.pictureBox192.Size = new System.Drawing.Size(14, 15);
            this.pictureBox192.TabIndex = 91;
            this.pictureBox192.TabStop = false;
            // 
            // pictureBox193
            // 
            this.pictureBox193.Location = new System.Drawing.Point(77, 116);
            this.pictureBox193.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox193.Name = "pictureBox193";
            this.pictureBox193.Size = new System.Drawing.Size(14, 15);
            this.pictureBox193.TabIndex = 90;
            this.pictureBox193.TabStop = false;
            // 
            // pictureBox194
            // 
            this.pictureBox194.Location = new System.Drawing.Point(77, 93);
            this.pictureBox194.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox194.Name = "pictureBox194";
            this.pictureBox194.Size = new System.Drawing.Size(14, 15);
            this.pictureBox194.TabIndex = 89;
            this.pictureBox194.TabStop = false;
            // 
            // pictureBox195
            // 
            this.pictureBox195.Location = new System.Drawing.Point(77, 74);
            this.pictureBox195.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox195.Name = "pictureBox195";
            this.pictureBox195.Size = new System.Drawing.Size(14, 15);
            this.pictureBox195.TabIndex = 88;
            this.pictureBox195.TabStop = false;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(13, 159);
            this.label48.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(64, 13);
            this.label48.TabIndex = 87;
            this.label48.Text = "18:00-20:00";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(13, 138);
            this.label49.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(64, 13);
            this.label49.TabIndex = 86;
            this.label49.Text = "16:00-18:00";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(13, 116);
            this.label50.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(64, 13);
            this.label50.TabIndex = 85;
            this.label50.Text = "14:00-16:00";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(13, 93);
            this.label51.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(64, 13);
            this.label51.TabIndex = 84;
            this.label51.Text = "12:00-14:00";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(13, 74);
            this.label52.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(64, 13);
            this.label52.TabIndex = 83;
            this.label52.Text = "10:00-12:00";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(18, 54);
            this.label53.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(58, 13);
            this.label53.TabIndex = 82;
            this.label53.Text = "8:00-10:00";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(244, 32);
            this.label54.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(26, 13);
            this.label54.TabIndex = 81;
            this.label54.Text = "Sun";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(220, 32);
            this.label55.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(23, 13);
            this.label55.TabIndex = 80;
            this.label55.Text = "Sat";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(199, 32);
            this.label56.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(18, 13);
            this.label56.TabIndex = 79;
            this.label56.Text = "Fri";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(164, 32);
            this.label57.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(34, 13);
            this.label57.TabIndex = 78;
            this.label57.Text = "Thurs";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(132, 32);
            this.label58.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(30, 13);
            this.label58.TabIndex = 77;
            this.label58.Text = "Wed";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(104, 32);
            this.label59.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(26, 13);
            this.label59.TabIndex = 76;
            this.label59.Text = "Tue";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(75, 32);
            this.label60.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(28, 13);
            this.label60.TabIndex = 75;
            this.label60.Text = "Mon";
            // 
            // pictureBox196
            // 
            this.pictureBox196.Location = new System.Drawing.Point(77, 53);
            this.pictureBox196.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox196.Name = "pictureBox196";
            this.pictureBox196.Size = new System.Drawing.Size(14, 15);
            this.pictureBox196.TabIndex = 74;
            this.pictureBox196.TabStop = false;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.pictureBox197);
            this.tabPage5.Controls.Add(this.pictureBox198);
            this.tabPage5.Controls.Add(this.pictureBox199);
            this.tabPage5.Controls.Add(this.pictureBox200);
            this.tabPage5.Controls.Add(this.pictureBox201);
            this.tabPage5.Controls.Add(this.pictureBox202);
            this.tabPage5.Controls.Add(this.pictureBox203);
            this.tabPage5.Controls.Add(this.label61);
            this.tabPage5.Controls.Add(this.pictureBox204);
            this.tabPage5.Controls.Add(this.pictureBox205);
            this.tabPage5.Controls.Add(this.pictureBox206);
            this.tabPage5.Controls.Add(this.pictureBox207);
            this.tabPage5.Controls.Add(this.pictureBox208);
            this.tabPage5.Controls.Add(this.pictureBox209);
            this.tabPage5.Controls.Add(this.pictureBox210);
            this.tabPage5.Controls.Add(this.pictureBox211);
            this.tabPage5.Controls.Add(this.pictureBox212);
            this.tabPage5.Controls.Add(this.pictureBox213);
            this.tabPage5.Controls.Add(this.pictureBox214);
            this.tabPage5.Controls.Add(this.pictureBox215);
            this.tabPage5.Controls.Add(this.pictureBox216);
            this.tabPage5.Controls.Add(this.pictureBox217);
            this.tabPage5.Controls.Add(this.pictureBox218);
            this.tabPage5.Controls.Add(this.pictureBox219);
            this.tabPage5.Controls.Add(this.pictureBox220);
            this.tabPage5.Controls.Add(this.pictureBox221);
            this.tabPage5.Controls.Add(this.pictureBox222);
            this.tabPage5.Controls.Add(this.pictureBox223);
            this.tabPage5.Controls.Add(this.pictureBox224);
            this.tabPage5.Controls.Add(this.pictureBox225);
            this.tabPage5.Controls.Add(this.pictureBox226);
            this.tabPage5.Controls.Add(this.pictureBox227);
            this.tabPage5.Controls.Add(this.pictureBox228);
            this.tabPage5.Controls.Add(this.pictureBox229);
            this.tabPage5.Controls.Add(this.pictureBox230);
            this.tabPage5.Controls.Add(this.pictureBox231);
            this.tabPage5.Controls.Add(this.pictureBox232);
            this.tabPage5.Controls.Add(this.pictureBox233);
            this.tabPage5.Controls.Add(this.pictureBox234);
            this.tabPage5.Controls.Add(this.pictureBox235);
            this.tabPage5.Controls.Add(this.pictureBox236);
            this.tabPage5.Controls.Add(this.pictureBox237);
            this.tabPage5.Controls.Add(this.pictureBox238);
            this.tabPage5.Controls.Add(this.pictureBox239);
            this.tabPage5.Controls.Add(this.pictureBox240);
            this.tabPage5.Controls.Add(this.pictureBox241);
            this.tabPage5.Controls.Add(this.pictureBox242);
            this.tabPage5.Controls.Add(this.pictureBox243);
            this.tabPage5.Controls.Add(this.pictureBox244);
            this.tabPage5.Controls.Add(this.label62);
            this.tabPage5.Controls.Add(this.label63);
            this.tabPage5.Controls.Add(this.label64);
            this.tabPage5.Controls.Add(this.label65);
            this.tabPage5.Controls.Add(this.label66);
            this.tabPage5.Controls.Add(this.label67);
            this.tabPage5.Controls.Add(this.label68);
            this.tabPage5.Controls.Add(this.label69);
            this.tabPage5.Controls.Add(this.label70);
            this.tabPage5.Controls.Add(this.label71);
            this.tabPage5.Controls.Add(this.label72);
            this.tabPage5.Controls.Add(this.label73);
            this.tabPage5.Controls.Add(this.label74);
            this.tabPage5.Controls.Add(this.pictureBox245);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(277, 228);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "5th floor";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // pictureBox197
            // 
            this.pictureBox197.Location = new System.Drawing.Point(254, 177);
            this.pictureBox197.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox197.Name = "pictureBox197";
            this.pictureBox197.Size = new System.Drawing.Size(14, 15);
            this.pictureBox197.TabIndex = 136;
            this.pictureBox197.TabStop = false;
            // 
            // pictureBox198
            // 
            this.pictureBox198.Location = new System.Drawing.Point(226, 177);
            this.pictureBox198.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox198.Name = "pictureBox198";
            this.pictureBox198.Size = new System.Drawing.Size(14, 15);
            this.pictureBox198.TabIndex = 135;
            this.pictureBox198.TabStop = false;
            // 
            // pictureBox199
            // 
            this.pictureBox199.Location = new System.Drawing.Point(197, 179);
            this.pictureBox199.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox199.Name = "pictureBox199";
            this.pictureBox199.Size = new System.Drawing.Size(14, 15);
            this.pictureBox199.TabIndex = 134;
            this.pictureBox199.TabStop = false;
            // 
            // pictureBox200
            // 
            this.pictureBox200.Location = new System.Drawing.Point(168, 177);
            this.pictureBox200.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox200.Name = "pictureBox200";
            this.pictureBox200.Size = new System.Drawing.Size(14, 15);
            this.pictureBox200.TabIndex = 133;
            this.pictureBox200.TabStop = false;
            // 
            // pictureBox201
            // 
            this.pictureBox201.Location = new System.Drawing.Point(139, 179);
            this.pictureBox201.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox201.Name = "pictureBox201";
            this.pictureBox201.Size = new System.Drawing.Size(14, 15);
            this.pictureBox201.TabIndex = 132;
            this.pictureBox201.TabStop = false;
            // 
            // pictureBox202
            // 
            this.pictureBox202.Location = new System.Drawing.Point(106, 177);
            this.pictureBox202.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox202.Name = "pictureBox202";
            this.pictureBox202.Size = new System.Drawing.Size(14, 15);
            this.pictureBox202.TabIndex = 131;
            this.pictureBox202.TabStop = false;
            // 
            // pictureBox203
            // 
            this.pictureBox203.Location = new System.Drawing.Point(77, 179);
            this.pictureBox203.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox203.Name = "pictureBox203";
            this.pictureBox203.Size = new System.Drawing.Size(14, 15);
            this.pictureBox203.TabIndex = 130;
            this.pictureBox203.TabStop = false;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(13, 184);
            this.label61.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(64, 13);
            this.label61.TabIndex = 129;
            this.label61.Text = "20:00-22:00";
            // 
            // pictureBox204
            // 
            this.pictureBox204.Location = new System.Drawing.Point(254, 158);
            this.pictureBox204.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox204.Name = "pictureBox204";
            this.pictureBox204.Size = new System.Drawing.Size(14, 15);
            this.pictureBox204.TabIndex = 128;
            this.pictureBox204.TabStop = false;
            // 
            // pictureBox205
            // 
            this.pictureBox205.Location = new System.Drawing.Point(254, 138);
            this.pictureBox205.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox205.Name = "pictureBox205";
            this.pictureBox205.Size = new System.Drawing.Size(14, 15);
            this.pictureBox205.TabIndex = 127;
            this.pictureBox205.TabStop = false;
            // 
            // pictureBox206
            // 
            this.pictureBox206.Location = new System.Drawing.Point(254, 116);
            this.pictureBox206.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox206.Name = "pictureBox206";
            this.pictureBox206.Size = new System.Drawing.Size(14, 15);
            this.pictureBox206.TabIndex = 126;
            this.pictureBox206.TabStop = false;
            // 
            // pictureBox207
            // 
            this.pictureBox207.Location = new System.Drawing.Point(254, 93);
            this.pictureBox207.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox207.Name = "pictureBox207";
            this.pictureBox207.Size = new System.Drawing.Size(14, 15);
            this.pictureBox207.TabIndex = 125;
            this.pictureBox207.TabStop = false;
            // 
            // pictureBox208
            // 
            this.pictureBox208.Location = new System.Drawing.Point(254, 74);
            this.pictureBox208.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox208.Name = "pictureBox208";
            this.pictureBox208.Size = new System.Drawing.Size(14, 15);
            this.pictureBox208.TabIndex = 124;
            this.pictureBox208.TabStop = false;
            // 
            // pictureBox209
            // 
            this.pictureBox209.Location = new System.Drawing.Point(254, 53);
            this.pictureBox209.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox209.Name = "pictureBox209";
            this.pictureBox209.Size = new System.Drawing.Size(14, 15);
            this.pictureBox209.TabIndex = 123;
            this.pictureBox209.TabStop = false;
            // 
            // pictureBox210
            // 
            this.pictureBox210.Location = new System.Drawing.Point(226, 158);
            this.pictureBox210.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox210.Name = "pictureBox210";
            this.pictureBox210.Size = new System.Drawing.Size(14, 15);
            this.pictureBox210.TabIndex = 122;
            this.pictureBox210.TabStop = false;
            // 
            // pictureBox211
            // 
            this.pictureBox211.Location = new System.Drawing.Point(226, 138);
            this.pictureBox211.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox211.Name = "pictureBox211";
            this.pictureBox211.Size = new System.Drawing.Size(14, 15);
            this.pictureBox211.TabIndex = 121;
            this.pictureBox211.TabStop = false;
            // 
            // pictureBox212
            // 
            this.pictureBox212.Location = new System.Drawing.Point(226, 116);
            this.pictureBox212.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox212.Name = "pictureBox212";
            this.pictureBox212.Size = new System.Drawing.Size(14, 15);
            this.pictureBox212.TabIndex = 120;
            this.pictureBox212.TabStop = false;
            // 
            // pictureBox213
            // 
            this.pictureBox213.Location = new System.Drawing.Point(226, 93);
            this.pictureBox213.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox213.Name = "pictureBox213";
            this.pictureBox213.Size = new System.Drawing.Size(14, 15);
            this.pictureBox213.TabIndex = 119;
            this.pictureBox213.TabStop = false;
            // 
            // pictureBox214
            // 
            this.pictureBox214.Location = new System.Drawing.Point(226, 74);
            this.pictureBox214.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox214.Name = "pictureBox214";
            this.pictureBox214.Size = new System.Drawing.Size(14, 15);
            this.pictureBox214.TabIndex = 118;
            this.pictureBox214.TabStop = false;
            // 
            // pictureBox215
            // 
            this.pictureBox215.Location = new System.Drawing.Point(226, 53);
            this.pictureBox215.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox215.Name = "pictureBox215";
            this.pictureBox215.Size = new System.Drawing.Size(14, 15);
            this.pictureBox215.TabIndex = 117;
            this.pictureBox215.TabStop = false;
            // 
            // pictureBox216
            // 
            this.pictureBox216.Location = new System.Drawing.Point(197, 159);
            this.pictureBox216.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox216.Name = "pictureBox216";
            this.pictureBox216.Size = new System.Drawing.Size(14, 15);
            this.pictureBox216.TabIndex = 116;
            this.pictureBox216.TabStop = false;
            // 
            // pictureBox217
            // 
            this.pictureBox217.Location = new System.Drawing.Point(197, 138);
            this.pictureBox217.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox217.Name = "pictureBox217";
            this.pictureBox217.Size = new System.Drawing.Size(14, 15);
            this.pictureBox217.TabIndex = 115;
            this.pictureBox217.TabStop = false;
            // 
            // pictureBox218
            // 
            this.pictureBox218.Location = new System.Drawing.Point(197, 116);
            this.pictureBox218.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox218.Name = "pictureBox218";
            this.pictureBox218.Size = new System.Drawing.Size(14, 15);
            this.pictureBox218.TabIndex = 114;
            this.pictureBox218.TabStop = false;
            // 
            // pictureBox219
            // 
            this.pictureBox219.Location = new System.Drawing.Point(197, 93);
            this.pictureBox219.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox219.Name = "pictureBox219";
            this.pictureBox219.Size = new System.Drawing.Size(14, 15);
            this.pictureBox219.TabIndex = 113;
            this.pictureBox219.TabStop = false;
            // 
            // pictureBox220
            // 
            this.pictureBox220.Location = new System.Drawing.Point(197, 74);
            this.pictureBox220.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox220.Name = "pictureBox220";
            this.pictureBox220.Size = new System.Drawing.Size(14, 15);
            this.pictureBox220.TabIndex = 112;
            this.pictureBox220.TabStop = false;
            // 
            // pictureBox221
            // 
            this.pictureBox221.Location = new System.Drawing.Point(197, 53);
            this.pictureBox221.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox221.Name = "pictureBox221";
            this.pictureBox221.Size = new System.Drawing.Size(14, 15);
            this.pictureBox221.TabIndex = 111;
            this.pictureBox221.TabStop = false;
            // 
            // pictureBox222
            // 
            this.pictureBox222.Location = new System.Drawing.Point(168, 158);
            this.pictureBox222.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox222.Name = "pictureBox222";
            this.pictureBox222.Size = new System.Drawing.Size(14, 15);
            this.pictureBox222.TabIndex = 110;
            this.pictureBox222.TabStop = false;
            // 
            // pictureBox223
            // 
            this.pictureBox223.Location = new System.Drawing.Point(168, 138);
            this.pictureBox223.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox223.Name = "pictureBox223";
            this.pictureBox223.Size = new System.Drawing.Size(14, 15);
            this.pictureBox223.TabIndex = 109;
            this.pictureBox223.TabStop = false;
            // 
            // pictureBox224
            // 
            this.pictureBox224.Location = new System.Drawing.Point(168, 116);
            this.pictureBox224.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox224.Name = "pictureBox224";
            this.pictureBox224.Size = new System.Drawing.Size(14, 15);
            this.pictureBox224.TabIndex = 108;
            this.pictureBox224.TabStop = false;
            // 
            // pictureBox225
            // 
            this.pictureBox225.Location = new System.Drawing.Point(168, 93);
            this.pictureBox225.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox225.Name = "pictureBox225";
            this.pictureBox225.Size = new System.Drawing.Size(14, 15);
            this.pictureBox225.TabIndex = 107;
            this.pictureBox225.TabStop = false;
            // 
            // pictureBox226
            // 
            this.pictureBox226.Location = new System.Drawing.Point(168, 74);
            this.pictureBox226.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox226.Name = "pictureBox226";
            this.pictureBox226.Size = new System.Drawing.Size(14, 15);
            this.pictureBox226.TabIndex = 106;
            this.pictureBox226.TabStop = false;
            // 
            // pictureBox227
            // 
            this.pictureBox227.Location = new System.Drawing.Point(168, 53);
            this.pictureBox227.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox227.Name = "pictureBox227";
            this.pictureBox227.Size = new System.Drawing.Size(14, 15);
            this.pictureBox227.TabIndex = 105;
            this.pictureBox227.TabStop = false;
            // 
            // pictureBox228
            // 
            this.pictureBox228.Location = new System.Drawing.Point(139, 159);
            this.pictureBox228.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox228.Name = "pictureBox228";
            this.pictureBox228.Size = new System.Drawing.Size(14, 15);
            this.pictureBox228.TabIndex = 104;
            this.pictureBox228.TabStop = false;
            // 
            // pictureBox229
            // 
            this.pictureBox229.Location = new System.Drawing.Point(139, 138);
            this.pictureBox229.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox229.Name = "pictureBox229";
            this.pictureBox229.Size = new System.Drawing.Size(14, 15);
            this.pictureBox229.TabIndex = 103;
            this.pictureBox229.TabStop = false;
            // 
            // pictureBox230
            // 
            this.pictureBox230.Location = new System.Drawing.Point(139, 116);
            this.pictureBox230.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox230.Name = "pictureBox230";
            this.pictureBox230.Size = new System.Drawing.Size(14, 15);
            this.pictureBox230.TabIndex = 102;
            this.pictureBox230.TabStop = false;
            // 
            // pictureBox231
            // 
            this.pictureBox231.Location = new System.Drawing.Point(139, 93);
            this.pictureBox231.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox231.Name = "pictureBox231";
            this.pictureBox231.Size = new System.Drawing.Size(14, 15);
            this.pictureBox231.TabIndex = 101;
            this.pictureBox231.TabStop = false;
            // 
            // pictureBox232
            // 
            this.pictureBox232.Location = new System.Drawing.Point(139, 74);
            this.pictureBox232.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox232.Name = "pictureBox232";
            this.pictureBox232.Size = new System.Drawing.Size(14, 15);
            this.pictureBox232.TabIndex = 100;
            this.pictureBox232.TabStop = false;
            // 
            // pictureBox233
            // 
            this.pictureBox233.Location = new System.Drawing.Point(139, 53);
            this.pictureBox233.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox233.Name = "pictureBox233";
            this.pictureBox233.Size = new System.Drawing.Size(14, 15);
            this.pictureBox233.TabIndex = 99;
            this.pictureBox233.TabStop = false;
            // 
            // pictureBox234
            // 
            this.pictureBox234.Location = new System.Drawing.Point(106, 158);
            this.pictureBox234.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox234.Name = "pictureBox234";
            this.pictureBox234.Size = new System.Drawing.Size(14, 15);
            this.pictureBox234.TabIndex = 98;
            this.pictureBox234.TabStop = false;
            // 
            // pictureBox235
            // 
            this.pictureBox235.Location = new System.Drawing.Point(106, 138);
            this.pictureBox235.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox235.Name = "pictureBox235";
            this.pictureBox235.Size = new System.Drawing.Size(14, 15);
            this.pictureBox235.TabIndex = 97;
            this.pictureBox235.TabStop = false;
            // 
            // pictureBox236
            // 
            this.pictureBox236.Location = new System.Drawing.Point(106, 116);
            this.pictureBox236.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox236.Name = "pictureBox236";
            this.pictureBox236.Size = new System.Drawing.Size(14, 15);
            this.pictureBox236.TabIndex = 96;
            this.pictureBox236.TabStop = false;
            // 
            // pictureBox237
            // 
            this.pictureBox237.Location = new System.Drawing.Point(106, 93);
            this.pictureBox237.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox237.Name = "pictureBox237";
            this.pictureBox237.Size = new System.Drawing.Size(14, 15);
            this.pictureBox237.TabIndex = 95;
            this.pictureBox237.TabStop = false;
            // 
            // pictureBox238
            // 
            this.pictureBox238.Location = new System.Drawing.Point(106, 74);
            this.pictureBox238.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox238.Name = "pictureBox238";
            this.pictureBox238.Size = new System.Drawing.Size(14, 15);
            this.pictureBox238.TabIndex = 94;
            this.pictureBox238.TabStop = false;
            // 
            // pictureBox239
            // 
            this.pictureBox239.Location = new System.Drawing.Point(106, 53);
            this.pictureBox239.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox239.Name = "pictureBox239";
            this.pictureBox239.Size = new System.Drawing.Size(14, 15);
            this.pictureBox239.TabIndex = 93;
            this.pictureBox239.TabStop = false;
            // 
            // pictureBox240
            // 
            this.pictureBox240.Location = new System.Drawing.Point(77, 159);
            this.pictureBox240.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox240.Name = "pictureBox240";
            this.pictureBox240.Size = new System.Drawing.Size(14, 15);
            this.pictureBox240.TabIndex = 92;
            this.pictureBox240.TabStop = false;
            // 
            // pictureBox241
            // 
            this.pictureBox241.Location = new System.Drawing.Point(77, 138);
            this.pictureBox241.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox241.Name = "pictureBox241";
            this.pictureBox241.Size = new System.Drawing.Size(14, 15);
            this.pictureBox241.TabIndex = 91;
            this.pictureBox241.TabStop = false;
            // 
            // pictureBox242
            // 
            this.pictureBox242.Location = new System.Drawing.Point(77, 116);
            this.pictureBox242.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox242.Name = "pictureBox242";
            this.pictureBox242.Size = new System.Drawing.Size(14, 15);
            this.pictureBox242.TabIndex = 90;
            this.pictureBox242.TabStop = false;
            // 
            // pictureBox243
            // 
            this.pictureBox243.Location = new System.Drawing.Point(77, 93);
            this.pictureBox243.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox243.Name = "pictureBox243";
            this.pictureBox243.Size = new System.Drawing.Size(14, 15);
            this.pictureBox243.TabIndex = 89;
            this.pictureBox243.TabStop = false;
            // 
            // pictureBox244
            // 
            this.pictureBox244.Location = new System.Drawing.Point(77, 74);
            this.pictureBox244.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox244.Name = "pictureBox244";
            this.pictureBox244.Size = new System.Drawing.Size(14, 15);
            this.pictureBox244.TabIndex = 88;
            this.pictureBox244.TabStop = false;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(13, 159);
            this.label62.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(64, 13);
            this.label62.TabIndex = 87;
            this.label62.Text = "18:00-20:00";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(13, 138);
            this.label63.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(64, 13);
            this.label63.TabIndex = 86;
            this.label63.Text = "16:00-18:00";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(13, 116);
            this.label64.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(64, 13);
            this.label64.TabIndex = 85;
            this.label64.Text = "14:00-16:00";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(13, 93);
            this.label65.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(64, 13);
            this.label65.TabIndex = 84;
            this.label65.Text = "12:00-14:00";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(13, 74);
            this.label66.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(64, 13);
            this.label66.TabIndex = 83;
            this.label66.Text = "10:00-12:00";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(18, 54);
            this.label67.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(58, 13);
            this.label67.TabIndex = 82;
            this.label67.Text = "8:00-10:00";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(244, 32);
            this.label68.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(26, 13);
            this.label68.TabIndex = 81;
            this.label68.Text = "Sun";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(220, 32);
            this.label69.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(23, 13);
            this.label69.TabIndex = 80;
            this.label69.Text = "Sat";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(199, 32);
            this.label70.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(18, 13);
            this.label70.TabIndex = 79;
            this.label70.Text = "Fri";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(164, 32);
            this.label71.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(34, 13);
            this.label71.TabIndex = 78;
            this.label71.Text = "Thurs";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(132, 32);
            this.label72.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(30, 13);
            this.label72.TabIndex = 77;
            this.label72.Text = "Wed";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(104, 32);
            this.label73.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(26, 13);
            this.label73.TabIndex = 76;
            this.label73.Text = "Tue";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Location = new System.Drawing.Point(75, 32);
            this.label74.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(28, 13);
            this.label74.TabIndex = 75;
            this.label74.Text = "Mon";
            // 
            // pictureBox245
            // 
            this.pictureBox245.Location = new System.Drawing.Point(77, 53);
            this.pictureBox245.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox245.Name = "pictureBox245";
            this.pictureBox245.Size = new System.Drawing.Size(14, 15);
            this.pictureBox245.TabIndex = 74;
            this.pictureBox245.TabStop = false;
            // 
            // tbFloorWashroom
            // 
            this.tbFloorWashroom.Location = new System.Drawing.Point(66, 102);
            this.tbFloorWashroom.Name = "tbFloorWashroom";
            this.tbFloorWashroom.Size = new System.Drawing.Size(147, 20);
            this.tbFloorWashroom.TabIndex = 32;
            // 
            // dtpicker_TimeWash
            // 
            this.dtpicker_TimeWash.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dtpicker_TimeWash.Location = new System.Drawing.Point(66, 66);
            this.dtpicker_TimeWash.Name = "dtpicker_TimeWash";
            this.dtpicker_TimeWash.ShowUpDown = true;
            this.dtpicker_TimeWash.Size = new System.Drawing.Size(147, 20);
            this.dtpicker_TimeWash.TabIndex = 33;
            this.dtpicker_TimeWash.Value = new System.DateTime(2023, 4, 21, 12, 28, 50, 0);
            // 
            // WashingRoom
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 366);
            this.Controls.Add(this.groupBox1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "WashingRoom";
            this.Text = "WashingRoom";
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox30)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox35)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox36)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox37)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox38)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox39)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox40)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox41)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox42)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox43)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox44)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox45)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox46)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox47)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox48)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox49)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox50)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox51)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox52)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox53)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox54)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox55)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox56)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox57)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox58)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox59)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox60)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox61)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox62)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox63)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox64)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox65)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox66)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox67)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox68)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox69)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox70)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox71)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox72)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox73)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox74)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox75)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox76)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox77)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox78)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox79)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox80)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox81)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox82)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox83)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox84)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox85)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox86)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox87)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox88)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox89)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox90)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox91)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox92)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox93)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox94)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox95)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox96)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox97)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox98)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox99)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox100)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox101)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox102)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox103)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox104)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox105)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox106)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox107)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox108)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox109)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox110)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox111)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox112)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox113)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox114)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox115)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox116)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox117)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox118)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox119)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox120)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox121)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox122)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox123)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox124)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox125)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox126)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox127)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox128)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox129)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox130)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox131)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox132)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox133)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox134)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox135)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox136)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox137)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox138)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox139)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox140)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox141)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox142)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox143)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox144)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox145)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox146)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox147)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox148)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox149)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox150)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox151)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox152)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox153)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox154)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox155)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox156)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox157)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox158)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox159)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox160)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox161)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox162)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox163)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox164)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox165)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox166)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox167)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox168)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox169)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox170)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox171)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox172)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox173)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox174)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox175)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox176)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox177)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox178)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox179)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox180)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox181)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox182)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox183)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox184)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox185)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox186)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox187)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox188)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox189)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox190)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox191)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox192)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox193)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox194)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox195)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox196)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox197)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox198)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox199)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox200)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox201)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox202)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox203)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox204)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox205)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox206)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox207)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox208)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox209)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox210)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox211)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox212)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox213)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox214)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox215)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox216)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox217)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox218)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox219)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox220)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox221)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox222)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox223)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox224)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox225)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox226)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox227)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox228)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox229)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox230)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox231)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox232)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox233)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox234)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox235)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox236)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox237)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox238)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox239)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox240)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox241)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox242)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox243)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox244)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox245)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dtpicker_DateWash;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.PictureBox pictureBox17;
        private System.Windows.Forms.PictureBox pictureBox18;
        private System.Windows.Forms.PictureBox pictureBox19;
        private System.Windows.Forms.PictureBox pictureBox20;
        private System.Windows.Forms.PictureBox pictureBox21;
        private System.Windows.Forms.PictureBox pictureBox22;
        private System.Windows.Forms.PictureBox pictureBox23;
        private System.Windows.Forms.PictureBox pictureBox24;
        private System.Windows.Forms.PictureBox pictureBox25;
        private System.Windows.Forms.PictureBox pictureBox26;
        private System.Windows.Forms.PictureBox pictureBox27;
        private System.Windows.Forms.PictureBox pictureBox28;
        private System.Windows.Forms.PictureBox pictureBox29;
        private System.Windows.Forms.PictureBox pictureBox30;
        private System.Windows.Forms.PictureBox pictureBox31;
        private System.Windows.Forms.PictureBox pictureBox32;
        private System.Windows.Forms.PictureBox pictureBox33;
        private System.Windows.Forms.PictureBox pictureBox34;
        private System.Windows.Forms.PictureBox pictureBox35;
        private System.Windows.Forms.PictureBox pictureBox36;
        private System.Windows.Forms.PictureBox pictureBox37;
        private System.Windows.Forms.PictureBox pictureBox38;
        private System.Windows.Forms.PictureBox pictureBox39;
        private System.Windows.Forms.PictureBox pictureBox40;
        private System.Windows.Forms.PictureBox pictureBox41;
        private System.Windows.Forms.PictureBox pictureBox42;
        private System.Windows.Forms.PictureBox pictureBox43;
        private System.Windows.Forms.PictureBox pictureBox44;
        private System.Windows.Forms.PictureBox pictureBox45;
        private System.Windows.Forms.PictureBox pictureBox46;
        private System.Windows.Forms.PictureBox pictureBox47;
        private System.Windows.Forms.PictureBox pictureBox48;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.PictureBox pictureBox49;
        private System.Windows.Forms.PictureBox pictureBox50;
        private System.Windows.Forms.PictureBox pictureBox51;
        private System.Windows.Forms.PictureBox pictureBox52;
        private System.Windows.Forms.PictureBox pictureBox53;
        private System.Windows.Forms.PictureBox pictureBox54;
        private System.Windows.Forms.PictureBox pictureBox55;
        private System.Windows.Forms.PictureBox pictureBox56;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox57;
        private System.Windows.Forms.PictureBox pictureBox58;
        private System.Windows.Forms.PictureBox pictureBox59;
        private System.Windows.Forms.PictureBox pictureBox60;
        private System.Windows.Forms.PictureBox pictureBox61;
        private System.Windows.Forms.PictureBox pictureBox62;
        private System.Windows.Forms.PictureBox pictureBox63;
        private System.Windows.Forms.PictureBox pictureBox64;
        private System.Windows.Forms.PictureBox pictureBox65;
        private System.Windows.Forms.PictureBox pictureBox66;
        private System.Windows.Forms.PictureBox pictureBox67;
        private System.Windows.Forms.PictureBox pictureBox68;
        private System.Windows.Forms.PictureBox pictureBox69;
        private System.Windows.Forms.PictureBox pictureBox70;
        private System.Windows.Forms.PictureBox pictureBox71;
        private System.Windows.Forms.PictureBox pictureBox72;
        private System.Windows.Forms.PictureBox pictureBox73;
        private System.Windows.Forms.PictureBox pictureBox74;
        private System.Windows.Forms.PictureBox pictureBox75;
        private System.Windows.Forms.PictureBox pictureBox76;
        private System.Windows.Forms.PictureBox pictureBox77;
        private System.Windows.Forms.PictureBox pictureBox78;
        private System.Windows.Forms.PictureBox pictureBox79;
        private System.Windows.Forms.PictureBox pictureBox80;
        private System.Windows.Forms.PictureBox pictureBox81;
        private System.Windows.Forms.PictureBox pictureBox82;
        private System.Windows.Forms.PictureBox pictureBox83;
        private System.Windows.Forms.PictureBox pictureBox84;
        private System.Windows.Forms.PictureBox pictureBox85;
        private System.Windows.Forms.PictureBox pictureBox86;
        private System.Windows.Forms.PictureBox pictureBox87;
        private System.Windows.Forms.PictureBox pictureBox88;
        private System.Windows.Forms.PictureBox pictureBox89;
        private System.Windows.Forms.PictureBox pictureBox90;
        private System.Windows.Forms.PictureBox pictureBox91;
        private System.Windows.Forms.PictureBox pictureBox92;
        private System.Windows.Forms.PictureBox pictureBox93;
        private System.Windows.Forms.PictureBox pictureBox94;
        private System.Windows.Forms.PictureBox pictureBox95;
        private System.Windows.Forms.PictureBox pictureBox96;
        private System.Windows.Forms.PictureBox pictureBox97;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.PictureBox pictureBox98;
        private System.Windows.Forms.PictureBox pictureBox99;
        private System.Windows.Forms.PictureBox pictureBox100;
        private System.Windows.Forms.PictureBox pictureBox101;
        private System.Windows.Forms.PictureBox pictureBox102;
        private System.Windows.Forms.PictureBox pictureBox103;
        private System.Windows.Forms.PictureBox pictureBox104;
        private System.Windows.Forms.PictureBox pictureBox105;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.PictureBox pictureBox106;
        private System.Windows.Forms.PictureBox pictureBox107;
        private System.Windows.Forms.PictureBox pictureBox108;
        private System.Windows.Forms.PictureBox pictureBox109;
        private System.Windows.Forms.PictureBox pictureBox110;
        private System.Windows.Forms.PictureBox pictureBox111;
        private System.Windows.Forms.PictureBox pictureBox112;
        private System.Windows.Forms.PictureBox pictureBox113;
        private System.Windows.Forms.PictureBox pictureBox114;
        private System.Windows.Forms.PictureBox pictureBox115;
        private System.Windows.Forms.PictureBox pictureBox116;
        private System.Windows.Forms.PictureBox pictureBox117;
        private System.Windows.Forms.PictureBox pictureBox118;
        private System.Windows.Forms.PictureBox pictureBox119;
        private System.Windows.Forms.PictureBox pictureBox120;
        private System.Windows.Forms.PictureBox pictureBox121;
        private System.Windows.Forms.PictureBox pictureBox122;
        private System.Windows.Forms.PictureBox pictureBox123;
        private System.Windows.Forms.PictureBox pictureBox124;
        private System.Windows.Forms.PictureBox pictureBox125;
        private System.Windows.Forms.PictureBox pictureBox126;
        private System.Windows.Forms.PictureBox pictureBox127;
        private System.Windows.Forms.PictureBox pictureBox128;
        private System.Windows.Forms.PictureBox pictureBox129;
        private System.Windows.Forms.PictureBox pictureBox130;
        private System.Windows.Forms.PictureBox pictureBox131;
        private System.Windows.Forms.PictureBox pictureBox132;
        private System.Windows.Forms.PictureBox pictureBox133;
        private System.Windows.Forms.PictureBox pictureBox134;
        private System.Windows.Forms.PictureBox pictureBox135;
        private System.Windows.Forms.PictureBox pictureBox136;
        private System.Windows.Forms.PictureBox pictureBox137;
        private System.Windows.Forms.PictureBox pictureBox138;
        private System.Windows.Forms.PictureBox pictureBox139;
        private System.Windows.Forms.PictureBox pictureBox140;
        private System.Windows.Forms.PictureBox pictureBox141;
        private System.Windows.Forms.PictureBox pictureBox142;
        private System.Windows.Forms.PictureBox pictureBox143;
        private System.Windows.Forms.PictureBox pictureBox144;
        private System.Windows.Forms.PictureBox pictureBox145;
        private System.Windows.Forms.PictureBox pictureBox146;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.PictureBox pictureBox147;
        private System.Windows.Forms.PictureBox pictureBox148;
        private System.Windows.Forms.PictureBox pictureBox149;
        private System.Windows.Forms.PictureBox pictureBox150;
        private System.Windows.Forms.PictureBox pictureBox151;
        private System.Windows.Forms.PictureBox pictureBox152;
        private System.Windows.Forms.PictureBox pictureBox153;
        private System.Windows.Forms.PictureBox pictureBox154;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.PictureBox pictureBox155;
        private System.Windows.Forms.PictureBox pictureBox156;
        private System.Windows.Forms.PictureBox pictureBox157;
        private System.Windows.Forms.PictureBox pictureBox158;
        private System.Windows.Forms.PictureBox pictureBox159;
        private System.Windows.Forms.PictureBox pictureBox160;
        private System.Windows.Forms.PictureBox pictureBox161;
        private System.Windows.Forms.PictureBox pictureBox162;
        private System.Windows.Forms.PictureBox pictureBox163;
        private System.Windows.Forms.PictureBox pictureBox164;
        private System.Windows.Forms.PictureBox pictureBox165;
        private System.Windows.Forms.PictureBox pictureBox166;
        private System.Windows.Forms.PictureBox pictureBox167;
        private System.Windows.Forms.PictureBox pictureBox168;
        private System.Windows.Forms.PictureBox pictureBox169;
        private System.Windows.Forms.PictureBox pictureBox170;
        private System.Windows.Forms.PictureBox pictureBox171;
        private System.Windows.Forms.PictureBox pictureBox172;
        private System.Windows.Forms.PictureBox pictureBox173;
        private System.Windows.Forms.PictureBox pictureBox174;
        private System.Windows.Forms.PictureBox pictureBox175;
        private System.Windows.Forms.PictureBox pictureBox176;
        private System.Windows.Forms.PictureBox pictureBox177;
        private System.Windows.Forms.PictureBox pictureBox178;
        private System.Windows.Forms.PictureBox pictureBox179;
        private System.Windows.Forms.PictureBox pictureBox180;
        private System.Windows.Forms.PictureBox pictureBox181;
        private System.Windows.Forms.PictureBox pictureBox182;
        private System.Windows.Forms.PictureBox pictureBox183;
        private System.Windows.Forms.PictureBox pictureBox184;
        private System.Windows.Forms.PictureBox pictureBox185;
        private System.Windows.Forms.PictureBox pictureBox186;
        private System.Windows.Forms.PictureBox pictureBox187;
        private System.Windows.Forms.PictureBox pictureBox188;
        private System.Windows.Forms.PictureBox pictureBox189;
        private System.Windows.Forms.PictureBox pictureBox190;
        private System.Windows.Forms.PictureBox pictureBox191;
        private System.Windows.Forms.PictureBox pictureBox192;
        private System.Windows.Forms.PictureBox pictureBox193;
        private System.Windows.Forms.PictureBox pictureBox194;
        private System.Windows.Forms.PictureBox pictureBox195;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.PictureBox pictureBox196;
        private System.Windows.Forms.PictureBox pictureBox197;
        private System.Windows.Forms.PictureBox pictureBox198;
        private System.Windows.Forms.PictureBox pictureBox199;
        private System.Windows.Forms.PictureBox pictureBox200;
        private System.Windows.Forms.PictureBox pictureBox201;
        private System.Windows.Forms.PictureBox pictureBox202;
        private System.Windows.Forms.PictureBox pictureBox203;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.PictureBox pictureBox204;
        private System.Windows.Forms.PictureBox pictureBox205;
        private System.Windows.Forms.PictureBox pictureBox206;
        private System.Windows.Forms.PictureBox pictureBox207;
        private System.Windows.Forms.PictureBox pictureBox208;
        private System.Windows.Forms.PictureBox pictureBox209;
        private System.Windows.Forms.PictureBox pictureBox210;
        private System.Windows.Forms.PictureBox pictureBox211;
        private System.Windows.Forms.PictureBox pictureBox212;
        private System.Windows.Forms.PictureBox pictureBox213;
        private System.Windows.Forms.PictureBox pictureBox214;
        private System.Windows.Forms.PictureBox pictureBox215;
        private System.Windows.Forms.PictureBox pictureBox216;
        private System.Windows.Forms.PictureBox pictureBox217;
        private System.Windows.Forms.PictureBox pictureBox218;
        private System.Windows.Forms.PictureBox pictureBox219;
        private System.Windows.Forms.PictureBox pictureBox220;
        private System.Windows.Forms.PictureBox pictureBox221;
        private System.Windows.Forms.PictureBox pictureBox222;
        private System.Windows.Forms.PictureBox pictureBox223;
        private System.Windows.Forms.PictureBox pictureBox224;
        private System.Windows.Forms.PictureBox pictureBox225;
        private System.Windows.Forms.PictureBox pictureBox226;
        private System.Windows.Forms.PictureBox pictureBox227;
        private System.Windows.Forms.PictureBox pictureBox228;
        private System.Windows.Forms.PictureBox pictureBox229;
        private System.Windows.Forms.PictureBox pictureBox230;
        private System.Windows.Forms.PictureBox pictureBox231;
        private System.Windows.Forms.PictureBox pictureBox232;
        private System.Windows.Forms.PictureBox pictureBox233;
        private System.Windows.Forms.PictureBox pictureBox234;
        private System.Windows.Forms.PictureBox pictureBox235;
        private System.Windows.Forms.PictureBox pictureBox236;
        private System.Windows.Forms.PictureBox pictureBox237;
        private System.Windows.Forms.PictureBox pictureBox238;
        private System.Windows.Forms.PictureBox pictureBox239;
        private System.Windows.Forms.PictureBox pictureBox240;
        private System.Windows.Forms.PictureBox pictureBox241;
        private System.Windows.Forms.PictureBox pictureBox242;
        private System.Windows.Forms.PictureBox pictureBox243;
        private System.Windows.Forms.PictureBox pictureBox244;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.PictureBox pictureBox245;
        private System.Windows.Forms.TextBox tbFloorWashroom;
        private System.Windows.Forms.DateTimePicker dtpicker_TimeWash;
    }
}